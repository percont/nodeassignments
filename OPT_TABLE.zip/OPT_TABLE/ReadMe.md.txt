This folder must contain any OPT tables created for NI project.
The following rules must be followed:
- any script must be re-runnable (Check existence of objects before trying to create them)
- dependencies must be respected (e.g. if a table has a foreign key on another table, the table with the dependency must be created after.)