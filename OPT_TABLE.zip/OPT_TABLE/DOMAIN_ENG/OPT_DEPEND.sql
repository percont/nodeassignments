declare
-- ABOLDESCU, PEI-3113, Tool for checking the Components folder's integrity

  TabName       dtype.Name    %type := 'OPT_DEPEND';
  c             dtype.Counter %type;
  sqlStr        dtype.LongStr %type;
  rc            dtype.Counter %type;
begin
  
  rc := stnd.process_start('OPT_TABLE: ' || TabName || ' - Create table', null, stnd.No);
  
  select min(1) into c from user_tables where table_name = TabName;
  
  if c is null then
    -- Table
    sqlStr := 
      '
      CREATE TABLE OPT_DEPEND
      (
        ID NUMBER(18) NOT NULL CONSTRAINT PK_OPT_DEPEND PRIMARY KEY,
        PARENT_ID NUMBER(18) ,
        NODE_TYPE VARCHAR2(255 CHAR) ,
        NODE_TYPE2 VARCHAR2(255 CHAR) ,
        IDT VARCHAR2(500 CHAR) ,
        PARENT_IDT VARCHAR2(500 CHAR) ,
        NAME VARCHAR2(4000 CHAR) ,
        data1 VARCHAR2(4000 CHAR) ,
        data2 VARCHAR2(4000 CHAR) ,
        data3 VARCHAR2(4000 CHAR) ,
        data4 VARCHAR2(4000 CHAR) ,
        SEQ_NUMBER NUMBER(18)
      ) TABLESPACE OWLARGE_D
      ';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Table created.');
    --sequence
    sqlStr := 'CREATE SEQUENCE OPT_DEPEND_SEQ';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Sequence created.');
    --trigger
    sqlStr := 
      '
      CREATE OR REPLACE TRIGGER OPT_DEPEND_TIBS
        BEFORE INSERT ON OPT_DEPEND
        for each row
      begin
        IF :new.ID IS NULL THEN
          SELECT OPT_DEPEND_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
          oracle_trgsupp.LastId := :new.ID;
        END IF;
      end;
      ';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Trigger created.');
    --index
    sqlStr := 'CREATE INDEX OPT_DEPEND_PARENT_ID ON OPT_DEPEND (PARENT_ID) TABLESPACE OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created: ' || sqlStr);
    
    sqlStr := 'CREATE INDEX OPT_DEPEND_NODE_TYPE ON OPT_DEPEND (NODE_TYPE, NODE_TYPE2) TABLESPACE OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created: ' || sqlStr);
    
    sqlStr := 'CREATE INDEX OPT_DEPEND_IDT ON OPT_DEPEND (IDT, PARENT_IDT) TABLESPACE OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created: ' || sqlStr);
    
    sqlStr := 'CREATE INDEX OPT_DEPEND_PARENT_IDT ON OPT_DEPEND (PARENT_IDT, IDT) TABLESPACE OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created: ' || sqlStr);
  else
    stnd.process_message(stnd.Information, 'Table already exists. Skipped!');
  end if;
  
  stnd.process_end;
  
end;
/
