DECLARE
  --the file has an exotic template because it cannot use opt_ctr_util, because opt_ctr_util references this table
  TableName dtype.Name%type := 'OPT_CTR_LOG';
  TableCount dtype.Counter%type;
  --IsTestEnv dtype.Tag%type; --NI-ABOLDESCU, this DDL is designed to be schema-independent, hence the notion of TestEnv is not applicable
  ToRecreate dtype.Tag%type := stnd.No;
  --OnlyRecreateOnTest dtype.Tag%type := stnd.Yes;
  SqlStr VARCHAR2(32000);
  rc dtype.Counter %type;
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    sy_process.PROCESS_MESSAGE(stnd.Information, SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
    rc := sy_process.ADD_CURRENT_NUMBER(1);
  END;
  
  procedure CREATE_TIBS(
    TableNameIn dtype.Name%type
  )
  IS
  BEGIN
    EXEC_SQL('CREATE SEQUENCE ' || TableNameIn || '_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 10 START WITH 1 CACHE 20 NOORDER');
    EXEC_SQL('CREATE OR REPLACE TRIGGER ' || TableNameIn || '_TIBS
  BEFORE INSERT ON ' || TableNameIn || '
  for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT ' || TableNameIn || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;
');
  END;
  
  function TO_SKIP_CREATION(
    TableNameIn dtype.Name%type
  ) RETURN dtype.Tag%type
  IS
    Result dtype.Tag%type := stnd.No;
  BEGIN
    
    sy_process.PROCESS_MESSAGE(stnd.Information
      , 'Start'
      || '; ToRecreate=' || ToRecreate
    );
    
    for a in(
      select *
        from user_tables
        where table_name = TableNameIn
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP TABLE ' || a.table_name || ' CASCADE CONSTRAINTS');
      else
        sy_process.PROCESS_MESSAGE(stnd.Information, 'Table ' || a.table_name || ' exists and recreation is not enabled or possible');
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    for a in(
      select *
        from all_sequences
        where sequence_name = TableNameIn || '_SEQ'
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP SEQUENCE ' || a.sequence_name);
      else
        sy_process.PROCESS_MESSAGE(stnd.Information, 'Sequence ' || a.sequence_name || ' exists and recreation is not enabled or possible');
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    RETURN Result;
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ sy_process.START_SIMPLE(ProcessName => FileName, ProcessParms => null);
  
  if TO_SKIP_CREATION(TableName) = stnd.Yes then GOTO SKIP; end if;
  
  EXEC_SQL(q'[create table OPT_CTR_LOG (
    id                NUMBER(18)      NOT NULL
  , idt               VARCHAR2(255)                 --NOT NULL in the original concept
  , pack_idt          VARCHAR2(255)                 --NOT NULL in the original concept
  , source_region     VARCHAR2(32)                  --NOT NULL in the original concept
  , jira_key          VARCHAR2(20)                  --NOT NULL in the original concept
  , change_type       VARCHAR2(1)                   --NOT NULL in the original concept
  , table_code        VARCHAR2(255)   NOT NULL
  , record_id         NUMBER(18)                    --NOT NULL in the original concept
  , process_log__oid  NUMBER(18)      
  , record_name       VARCHAR2(4000)  
  , f_i               VARCHAR2(32)    
  , apply_status      VARCHAR2(1)     
  , error_level       VARCHAR2(1)     
  , release_idt       VARCHAR2(20)    
  , que_time          TIMESTAMP       DEFAULT CURRENT_TIMESTAMP(9) NOT NULL
  , apply_time        TIMESTAMP       
  , history_id        NUMBER(18)      
  , change_source     CLOB            CONSTRAINT OPT_CTR_LOG_change_source_json CHECK (change_source IS JSON)
  , change_target     CLOB            CONSTRAINT OPT_CTR_LOG_change_target_json CHECK (change_target IS JSON)
)
  TABLESPACE OWLARGE_D]');
  
  CREATE_TIBS(TableName);
  -- Indexes
  EXEC_SQL(q'[CREATE UNIQUE INDEX PK_OPT_CTR_LOG    ON OPT_CTR_LOG (ID)                                 TABLESPACE OWLARGE_I]');
  EXEC_SQL(q'[CREATE INDEX OPT_CTR_LOG_JIRA_KEY     ON OPT_CTR_LOG (JIRA_KEY)                           TABLESPACE OWLARGE_I]');
  EXEC_SQL(q'[CREATE INDEX OPT_CTR_LOG_PACK_IDT     ON OPT_CTR_LOG (PACK_IDT)                           TABLESPACE OWLARGE_I]');
  EXEC_SQL(q'[CREATE INDEX OPT_CTR_LOG_PROCESS      ON OPT_CTR_LOG (process_log__oid)                   TABLESPACE OWLARGE_I]');
  EXEC_SQL(q'[CREATE INDEX OPT_CTR_LOG_FIND_CURRENT ON OPT_CTR_LOG (TABLE_CODE, RECORD_ID, CHANGE_TYPE) TABLESPACE OWLARGE_I]');
  EXEC_SQL(q'[CREATE INDEX OPT_CTR_LOG_QUE_TIME     ON OPT_CTR_LOG (QUE_TIME)                           TABLESPACE OWLARGE_I]');
  --Constraints
  EXEC_SQL(q'[ALTER TABLE OPT_CTR_LOG ADD (CONSTRAINT PK_OPT_CTR_LOG PRIMARY KEY (ID) USING INDEX PK_OPT_CTR_LOG ENABLE VALIDATE)]');
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ sy_process.PROCESS_END;
END;
/