DECLARE
  --2019-03-24, NI-ABOLDESCU, PEI-4345, New HBSync framework
  TableCount dtype.Counter%type;
  SqlStr dtype.LongStr%type;
  ProcRc dtype.Counter%type;
  ToRecreate dtype.Tag%type := stnd.Yes;
  OnlyRecreateOnTest dtype.Tag%type := stnd.Yes;
  IsTestEnv dtype.Tag%type;
BEGIN
  ProcRc := stnd.PROCESS_START('OPT_TEMP_HBSYNC.sql: DDL: Table', null, stnd.No);

  IsTestEnv := opt_flex_tools.IS_TEST_ENV;
  stnd.PROCESS_MESSAGE(stnd.Information, 'IsTestEnv='||IsTestEnv);
  
  if IsTestEnv = stnd.No and OnlyRecreateOnTest = stnd.Yes then
    ToRecreate := stnd.No;
  end if;
  
  select count(*) into TableCount from user_tables where table_name = 'OPT_TEMP_HBSYNC';

  if TableCount > 0 and ToRecreate = stnd.Yes then
    SqlStr := 'drop table OPT_TEMP_HBSYNC cascade constraints';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table dropped.');
  elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table OPT_TEMP_HBSYNC exists and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
  
  -- Table
  SqlStr := 'CREATE GLOBAL TEMPORARY TABLE OPT_TEMP_HBSYNC
(
    data_source     VARCHAR2(32 CHAR)    
  , group_code_main VARCHAR2(255 CHAR)   
  , key_main        VARCHAR2(32 CHAR)    
  , main_sub        VARCHAR2(32 CHAR)    
  , group_code      VARCHAR2(32 CHAR)    
  , key_self        VARCHAR2(255 CHAR)   
  , code            VARCHAR2(32 CHAR)    
  , name            VARCHAR2(255 CHAR)   
  , filter          VARCHAR2(32 CHAR)    
  , filter2         VARCHAR2(32 CHAR)    
  , filter3         VARCHAR2(32 CHAR)    
  , filter4         VARCHAR2(32 CHAR)    
  , filter5         VARCHAR2(32 CHAR)    
  , int_filter      NUMBER(9)            DEFAULT 0
  , id_filter1      NUMBER(18)           
  , id_filter2      NUMBER(18)           
  , rec_hash        VARCHAR2(255 CHAR)   
  , rec_id          NUMBER(18)           
)
ON COMMIT PRESERVE ROWS';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table created.');
  
  -- Indexes
  SqlStr := 'CREATE INDEX OPT_TEMP_HBSYNC_I1 ON OPT_TEMP_HBSYNC (data_source, group_code_main, key_main, main_sub, group_code, key_self)';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');
  
  -- Indexes
  SqlStr := 'CREATE INDEX OPT_TEMP_HBSYNC_main_sub ON OPT_TEMP_HBSYNC (group_code_main, key_main, main_sub)';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  <<SKIP>>
  stnd.PROCESS_END;
END;
/