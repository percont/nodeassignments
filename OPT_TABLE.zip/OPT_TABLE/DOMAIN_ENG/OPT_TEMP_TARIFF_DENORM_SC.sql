DECLARE
/*
  20180405-001, NI-ABOLDESCU, AUBI-1638, Adding a custom table to store the archived contracts, primarily designed for the ones exluded from the data migration process
*/
  TableCount dtype.Counter%type;
  SqlStr dtype.LongStr%type;
  ProcRc dtype.Counter%type;
  ToRecreate dtype.Tag%type := stnd.No;
  OnlyRecreateOnTest dtype.Tag%type := stnd.Yes;
  IsTestEnv dtype.Tag%type;
  TempCount dtype.Counter%type;
BEGIN
  ProcRc := stnd.PROCESS_START('DDL: Table: CREATE OPT_TEMP_TARIFF_DENORM_SC', null, stnd.No);

  IsTestEnv := opt_flex_tools.IS_TEST_ENV;
  stnd.PROCESS_MESSAGE(stnd.Information, 'IsTestEnv='||IsTestEnv);
  
  if IsTestEnv = stnd.No and OnlyRecreateOnTest = stnd.Yes then
    ToRecreate := stnd.No;
  end if;
  
  select count(*) into TableCount from user_tables where table_name = 'OPT_TEMP_TARIFF_DENORM_SC';

  if TableCount > 0 and ToRecreate = stnd.Yes then
    SqlStr := 'drop table OPT_TEMP_TARIFF_DENORM_SC cascade constraints';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table dropped.');
  elsif TableCount > 0 then
  
  --adding columns
  select count(*) into TempCount from ALL_TAB_COLUMNS where column_name = 'IS_READY' and table_name = 'OPT_TEMP_TARIFF_DENORM_SC';
  if TempCount = 0 then
    SqlStr := 'ALTER TABLE OPT_TEMP_TARIFF_DENORM_SC ADD (is_ready VARCHAR2(1))';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
  end if;
  
  select count(*) into TempCount from ALL_TAB_COLUMNS where column_name = 'PRIORITY' and table_name = 'OPT_TEMP_TARIFF_DENORM_SC';
  if TempCount = 0 then
    SqlStr := 'ALTER TABLE OPT_TEMP_TARIFF_DENORM_SC ADD (PRIORITY NUMBER)';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
  end if;
  
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table OPT_TEMP_TARIFF_DENORM_SC exists and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
  
  -- Table
  SqlStr := 'CREATE GLOBAL TEMPORARY TABLE OPT_TEMP_TARIFF_DENORM_SC
(
        data_source VARCHAR2(255)
      , td_lvl NUMBER
      , td_path VARCHAR2(4000)
      , td_name VARCHAR2(4000)
      , td_apply_rules VARCHAR2(4000)
      , td_is_personal VARCHAR2(4000)
      , rnr_in_td NUMBER
      , table_code_from VARCHAR2(255)
      , tariff_role VARCHAR2(4000)
      , tariff_type VARCHAR2(4000)
      , name VARCHAR2(4000)
      , limit_tariff VARCHAR2(4000)
      , preference_type_code VARCHAR2(4000)
      , curr VARCHAR2(4000)
      , event_type VARCHAR2(4000)
      , apply_rules VARCHAR2(4000)
      , table_rules_from VARCHAR2(4000)
      , tariff_type_ext VARCHAR2(4000)
      , priority NUMBER
      , is_ready VARCHAR2(1)
      , tv_active_bool VARCHAR2(4000)
      , tv_is_active VARCHAR2(4000) DEFAULT ''D''
      , tv_curr VARCHAR2(4000)
      , fx_rate_type VARCHAR2(4000)
      , due_period NUMBER DEFAULT 0
      , due_period_grace NUMBER DEFAULT 0
      , max_amount NUMBER DEFAULT 0
      , min_amount NUMBER DEFAULT 0
      , min_rq_amount NUMBER DEFAULT 0
      , single_amount NUMBER DEFAULT 0
      , rate_pcnt NUMBER DEFAULT 0
      , fee_rate_pcnt NUMBER DEFAULT 0
      , min_count NUMBER DEFAULT 0
      , max_count NUMBER DEFAULT 0
      , gl_number VARCHAR2(4000)
      , tv_apply_rules VARCHAR2(4000)
      , nr_table_code_from NUMBER
      , tv_nr_not_ready NUMBER
      , tv_nr_future NUMBER
      , tv_is_good VARCHAR2(4000)
      , td_id NUMBER
      , t_id NUMBER
      , tv_id NUMBER
      , rnum_table_code_from NUMBER
)
ON COMMIT PRESERVE ROWS';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table created.');
  
  -- Indexes
  SqlStr := 'CREATE INDEX OPT_TEMP_TARIFF_DENORM_SC_I1 ON OPT_TEMP_TARIFF_DENORM_SC (DATA_SOURCE, TD_PATH, TABLE_CODE_FROM)';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  <<SKIP>>
  stnd.PROCESS_END;
END;
/