declare
    rc          dtype.counter   %type;
    istabexist  boolean                 := false;
    
    procedure reject(
        msg         in  dtype.errormessage  %type,
        procreject  in  dtype.tag           %type := stnd.yes
    )
    is
    begin
        sy_process.process_message(stnd.fatalerror, msg);
        if (procreject = stnd.yes) then
            sy_process.process_reject();
        else
            stnd.process_end;
        end if;
        sy_excpt.raise_exception(msg);
    end;

    procedure runstmt(
        sqlstmt     in  dtype.xmlstring     %type
    ) is
        c               dtype.counter       %type;
        timestart       dtype.currentdate   %type;
        timeend         dtype.currentdate   %type;
    begin
        begin
            timestart := sysdate;
            execute immediate sqlstmt;
            timeend := sysdate;
            sy_process.process_message(stnd.timing,  regexp_substr(numtodsinterval(timeend - timestart, 'day'), '\d{2}:\d{2}:\d{2}') || ', [' || sqlstmt || ']');
        exception when others then
            reject('Error: ' || sqlerrm || '; statement: [' || sqlstmt || ']');
        end;
    end;
begin
    rc := sy_process.process_start('OPT_TABLE: OPT_ACCEPT_DOCS table', null, stnd.yes);
    
    select count(1)
    into rc
    from user_tables
    where table_name = 'OPT_ACCEPT_DOCS';
    
    if (rc = 0) then
        istabexist := false;
    else
        istabexist := true;
    end if;
    
    if (not istabexist) then
        runstmt(
            'create table OPT_ACCEPT_DOCS ('                    || sy_convert.newline ||
            '    id          number(18, 0) unique not null,'    || sy_convert.newline ||
            '    doc_cat     varchar(1)       default null,'    || sy_convert.newline ||
            '    hash_value  number(18, 0)        not null'     || sy_convert.newline ||
            ')'                                                 || sy_convert.newline ||
            'partition by list (doc_cat) automatic ('           || sy_convert.newline ||
            '    partition other values (null)'                 || sy_convert.newline ||
            ')'                                                 || sy_convert.newline ||
            'tablespace OWMEDIUM_D'                             || sy_convert.newline ||
            'storage ('                                         || sy_convert.newline ||
            '    initial 100M'                                  || sy_convert.newline ||
            '    next 100M'                                     || sy_convert.newline ||
            '    pctincrease 0'                                 || sy_convert.newline ||
            ')'
        );
        sy_process.process_message(stnd.information, 'Table OPT_ACCEPT_DOCS created');
    end if;
    
    sy_process.process_end;
end;
/
