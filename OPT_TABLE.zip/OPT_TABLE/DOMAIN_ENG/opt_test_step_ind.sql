declare
  rc      dtype.counter   %type;
  squery  dtype.longstr   %type;
  cnt     dtype.counter   %type;
    
  procedure reject(
    msg in dtype.errormessage  %type
  )
  is
  begin
    sy_process.process_message(stnd.fatalerror, msg);
    sy_process.process_reject();
    sy_excpt.raise_exception(msg);
  end;

  procedure exeone(
    stmt in dtype.longstr %type
  ) is
  begin
    stnd.process_message(stnd.information, stmt);
    execute immediate stmt;

    exception when others then
      reject('something failed: ' || sqlerrm);
  end;

begin
  rc := sy_process.process_start('OPT_TEST_STEP: create OPT_TEST_STEP index', null, stnd.yes);

  select count(*) into cnt 
   from user_indexes 
  where index_name = upper('opt_test_step');

  if cnt > 0 then
    exeone('drop index opt_test_step');
  end if;
 select count(*) into cnt 
   from user_indexes 
  where index_name = upper('test_step2');

  if cnt > 0 then
    exeone('drop index test_step2');
  end if;

  exeone('create index opt_test_step on test_step (step_n, test_scheme__oid, step_status, special_parms, amnd_state) tablespace OWLARGE_I');

  sy_process.process_end();
end;
/