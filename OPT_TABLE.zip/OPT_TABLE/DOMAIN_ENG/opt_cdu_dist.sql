declare
    rc          dtype.counter   %type;
    istabexist  boolean                 := true;
    
    procedure reject(
        msg         in  dtype.errormessage  %type,
        procreject  in  dtype.tag           %type := stnd.yes
    )
    is
    begin
        sy_process.process_message(stnd.fatalerror, msg);
        if (procreject = stnd.yes) then
            sy_process.process_reject();
        else
            stnd.process_end;
        end if;
        sy_excpt.raise_exception(msg);
    end;

    procedure runstmt(
        sqlstmt     in  dtype.xmlstring     %type
    ) is
        c               dtype.counter       %type;
        timestart       dtype.currentdate   %type;
        timeend         dtype.currentdate   %type;
    begin
        begin
            timestart := sysdate;
            execute immediate sqlstmt;
            timeend := sysdate;
            sy_process.process_message(stnd.timing,  regexp_substr(numtodsinterval(timeend - timestart, 'day'), '\d{2}:\d{2}:\d{2}') || ', [' || sqlstmt || ']');
        exception when others then
            reject('Error: ' || sqlerrm || '; statement: [' || sqlstmt || ']');
        end;
    end;
begin
    rc := sy_process.process_start('OPT_TABLE: OPT_CDU_DIST table', null, stnd.yes);

    select count(1)
    into rc
    from user_tables
    where table_name = 'OPT_CDU_DIST';
    
    if (rc = 0) then
        istabexist := false;
        sy_process.process_message(stnd.information, 'Table OPT_CDU_DIST does not exist, creating table...');
    else
        sy_process.process_message(stnd.information, 'Table OPT_CDU_DIST exists, replacing with new table...');
    end if;
    commit;
    
    if (istabexist) then
        begin
            dbms_redefinition.can_redef_table('OWS', 'OPT_CDU_DIST');
        exception when others then
            reject('dbms_redefinition.can_redef_table: ' || sqlerrm);
        end;
    end if;
    
    runstmt(
        'create table OPT_CDU_DIST_NEW ( ' ||
        '    ID              number(18, 0)                   not null, ' ||
        '    THREAD_N        number(9, 0)                    not null, ' ||
        '    TREE_SIZE       number(9, 0)                    not null, ' ||
        '    LAST_SCAN       date                            not null, ' ||
        '    BILLING_TREE    number(9, 0)    default 0       not null, ' ||
        '    EFF_IPP         number(9, 0)    default 0       not null, ' ||
        '    DUE_IPP         number(9, 0)    default 0       not null, ' ||
        '    RATE            number(12, 2)   default 0       null, ' ||
        '    TIME_ZONE       number(9, 0)                    not null, ' ||
        '    CONTRACT_LEVEL  number(9, 0)    default 0       not null ' ||
        ') ' ||
        'partition by list (TIME_ZONE, CONTRACT_LEVEL) AUTOMATIC ( ' ||
        '    partition TZ2_DEVICE    values(2, -2), ' ||
        '    partition TZ2_LIAB1     values(2, 1), ' ||
        '    partition TZ2_TOP       values(2, 0), ' ||
        '    partition TZ2_BANK      values(2, -1), ' ||
        '    partition TZ0_LIAB1     values(0, 1), ' ||
        '    partition TZ0_TOP       values(0, 0), ' ||
        '    partition TZ0_BANK      values(0, -1), ' ||
        '    partition TZ1_DEVICE    values(1, -2), ' ||
        '    partition TZ1_TOP       values(1, 0), ' ||
        '    partition TZ1_BANK      values(1, -1), ' ||
        '    partition TZ11_DEVICE   values(11, -2), ' ||
        '    partition TZ11_TOP      values(11, 0), ' ||
        '    partition TZ11_BANK     values(11, -1) ' ||
        ') ' ||
        'tablespace OWMEDIUM_D ' ||
        'storage ( ' ||
        '    initial 100M ' ||
        '    next 100M ' ||
        '    pctincrease 0 ' ||
        ')'
    );
    commit;
    
    -- use dbms_redefinision to substitue existing table
    -- without touching grants or objects recompilation
    if (istabexist) then
        runstmt('alter session force parallel dml parallel 10');
        runstmt('alter session force parallel query parallel 10');
        commit;
        
        runstmt(
            'update /*+ parallel(10) */ OPT_CDU_DIST ' ||
            'set thread_n = trunc(dbms_random.value(0, 999)) ' ||
            'where thread_n is null'
        );
        commit;
        
        sy_process.process_message(stnd.information, 'Start redefinition...');
        commit;
        begin
            dbms_redefinition.start_redef_table(
                uname       =>  'OWS',
                orig_table  =>  'OPT_CDU_DIST',
                int_table   =>  'OPT_CDU_DIST_NEW'
            );
        exception when others then
            reject('dbms_redefinition.start_redef_table: ' || dbms_utility.format_error_stack);
        end;
        
        sy_process.process_message(stnd.information, 'Copy dependents...');
        commit;
        begin
            dbms_redefinition.copy_table_dependents(
                uname               =>  'OWS',
                orig_table          =>  'OPT_CDU_DIST',
                int_table           =>  'OPT_CDU_DIST_NEW',
                copy_indexes        =>  0,
                copy_triggers       =>  false,
                copy_constraints    =>  false,
                copy_privileges     =>  true,
                ignore_errors       =>  false,
                num_errors          =>  rc,
                copy_statistics     =>  false,
                copy_mvlog          =>  false
            );
        exception when others then
            reject('dbms_redefinition.copy_table_dependents: ' || sqlerrm);
        end;
    end if;
    
    runstmt(
        'create unique index OPT_CDU_DIST_PK_NEW on OPT_CDU_DIST_NEW(ID) ' ||
        'tablespace OWMEDIUM_I ' ||
        'storage ( ' ||
        '    initial 100M ' ||
        '    next 100M ' ||
        '    pctincrease 0 ' ||
        ')'
    );
    commit;
    runstmt('alter table OPT_CDU_DIST_NEW add constraint OPT_CDU_DIST_PK_NEW primary key (ID)');
    commit;
    
    if (istabexist) then
        sy_process.process_message(stnd.information, 'Gather stats...');
        commit;
        begin
            dbms_stats.gather_table_stats(
                ownname             =>  'OWS',
                tabname             =>  'OPT_CDU_DIST_NEW',
                estimate_percent    =>  10,
                cascade             =>  true,
                degree              =>  8,
                method_opt          =>  null
            );
        exception when others then
            reject('dbms_stats.gather_table_stats: ' || sqlerrm);
        end;
        
        sy_process.process_message(stnd.information, 'Finish redefinition...');
        commit;
        begin
            dbms_redefinition.finish_redef_table('OWS', 'OPT_CDU_DIST', 'OPT_CDU_DIST_NEW');
        exception when others then
            reject('dbms_redefinition.finish_redef_table: ' || sqlerrm);
        end;
        
        runstmt('drop table OPT_CDU_DIST_NEW');
    else
        runstmt('alter table OPT_CDU_DIST_NEW rename to OPT_CDU_DIST');
    end if;
    
    runstmt('alter index OPT_CDU_DIST_PK_NEW rename to OPT_CDU_DIST_PK');
    runstmt('alter table OPT_CDU_DIST rename constraint OPT_CDU_DIST_PK_NEW to OPT_CDU_DIST_PK');
    
    sy_process.process_end;
end;
/
