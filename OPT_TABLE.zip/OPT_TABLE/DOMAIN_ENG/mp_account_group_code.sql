declare
table_c number;
begin
select count(*) into table_c from user_objects where object_type = 'INDEX' and object_name = 'MP_ACCOUNT_GROUP_CODE';
if (table_c = 0) then
execute immediate 'CREATE INDEX OWS.MP_ACCOUNT_GROUP_CODE ON OWS.MP_ACCOUNT_GROUP  (code)';
end if;
end;
/
