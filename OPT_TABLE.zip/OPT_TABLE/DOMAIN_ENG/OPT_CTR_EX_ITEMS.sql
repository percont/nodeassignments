DECLARE
  TableName dtype.Name%type := 'OPT_CTR_EX_ITEMS';
  TableCount dtype.Counter%type;
  IsTestEnv dtype.Tag%type;
  ToRecreate dtype.Tag%type := stnd.No;
  OnlyRecreateOnTest dtype.Tag%type := stnd.Yes;
  SqlStr VARCHAR2(32000);
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  ToStartSession dtype.Tag%type := stnd.No;
  CommitInterval dtype.Counter%type := null; --Please only use for really big changes because, when used, the rollback in case of a process reject will not be full.
  OfficerUserId dtype.Name%type := 'OWS_A';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  ToReject dtype.Tag%type; AppErrorText dtype.LongStr%type; AppErrorNumber dtype.Counter%type; --here we can put values to get the process rolled back and rejected
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    opt_ctr_util.PROCESS_MESSAGE(SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Information);
    opt_ctr_util.RELEASE_SUBPROCESS_INCREMENT;
  EXCEPTION WHEN OTHERS THEN
    opt_ctr_util.PROCESS_MESSAGE_ATX(SUBSTR(REPLACE(REPLACE('Oracle raised error:"' || SQLERRM || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Error);
    opt_ctr_util.RELEASE_SUBPROCESS_END2(stnd.Yes, SUBSTR(REPLACE(REPLACE('Failed at SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
  END;
  
  procedure CREATE_TIBS(
    TableNameIn dtype.Name%type
  )
  IS
  BEGIN
    EXEC_SQL('CREATE SEQUENCE ' || TableNameIn || '_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER');
    EXEC_SQL('CREATE OR REPLACE TRIGGER ' || TableNameIn || '_TIBS
BEFORE INSERT ON ' || TableNameIn || '
for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT ' || TableNameIn || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;
');
  END;
  
  function TO_SKIP_CREATION(
    TableNameIn dtype.Name%type
  ) RETURN dtype.Tag%type
  IS
    Result dtype.Tag%type := stnd.No;
  BEGIN
    
    IsTestEnv := opt_flex_tools.IS_TEST_ENV;
    opt_ctr_util.PROCESS_MESSAGE('Table ' || TableNameIn || ' exists'
      || '; ToRecreate=' || ToRecreate
      || '; OnlyRecreateOnTest=' || OnlyRecreateOnTest
      || ': IsTestEnv=' || IsTestEnv
      , stnd.Information
    );
    if IsTestEnv = stnd.No and OnlyRecreateOnTest = stnd.Yes then
      ToRecreate := stnd.No;
    end if;
    
    for a in(
      select *
        from user_tables
        where table_name = TableNameIn
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP TABLE ' || a.table_name || ' CASCADE CONSTRAINTS');
      else
        opt_ctr_util.PROCESS_MESSAGE('Table ' || a.table_name || ' exists and recreation is not enabled or possible', stnd.Information);
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    for a in(
      select *
        from all_sequences
        where sequence_name = TableNameIn || '_SEQ'
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP SEQUENCE ' || a.sequence_name);
      else
        opt_ctr_util.PROCESS_MESSAGE('Sequence ' || a.sequence_name || ' exists and recreation is not enabled or possible', stnd.Information);
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    RETURN Result;
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_START_P(ProcessName => FileName, ToStartSession => ToStartSession, OfficerUserId => OfficerUserId); --other parms are ProcessParms, IsUnique, ObjectType, ObjectId
  
  if TO_SKIP_CREATION(TableName) = stnd.Yes then GOTO SKIP; end if;
  
  EXEC_SQL(q'[create table OPT_CTR_EX_ITEMS (
    id                 NUMBER(18)           NOT NULL  CONSTRAINT PK_OPT_CTR_EX_ITEMS PRIMARY KEY USING INDEX TABLESPACE OWMEDIUM_I
  , ex_group           VARCHAR2(32 CHAR)    NOT NULL  
  , table_code         VARCHAR2(26 CHAR)    NOT NULL  
  , parent_code        VARCHAR2(26 CHAR)              
  , table_code_real    VARCHAR2(26 CHAR)              
  , table_code_file    VARCHAR2(26 CHAR)              
  , table_seq          NUMBER(9)                      
  , subs_group         VARCHAR2(32 CHAR)              
  , is_dummy           VARCHAR2(1 CHAR)               
  , add_filter         VARCHAR2(4000 CHAR)            
  , fi_filter_ovr      VARCHAR2(4000 CHAR)            
  , fi_filter_ovr_null VARCHAR2(4000 CHAR)            
  , order_expr         VARCHAR2(4000 CHAR)            
  , prefix_expr        VARCHAR2(4000 CHAR)            
  , suffix_expr        VARCHAR2(4000 CHAR)            
  , subfolder_expr     VARCHAR2(4000 CHAR)            
  , add_fields         VARCHAR2(4000 CHAR)            
  , lev_offset         NUMBER(9)                      
  , ex_dialect         VARCHAR2(32 CHAR)              
  , ex_main_fields_ovr VARCHAR2(255 CHAR)             
  , ex_add_parms       VARCHAR2(4000 CHAR)            
  , del_tab            VARCHAR2(32 CHAR)              
  , del_filt           VARCHAR2(4000 CHAR)            
  , header_expr        VARCHAR2(4000 CHAR)            
  , footer_expr        VARCHAR2(4000 CHAR)            
  , ei_filter          VARCHAR2(4000 CHAR)            
  , ei_filter_items    VARCHAR2(255 CHAR)             
  , sql_before         VARCHAR2(4000 CHAR)            
  , add_info           VARCHAR2(4000 CHAR)            
)
  TABLESPACE OWMEDIUM_D]');
  CREATE_TIBS(TableName);
  
  EXEC_SQL(q'[CREATE UNIQUE INDEX OPT_CTR_EX_ITEMS_UN ON OPT_CTR_EX_ITEMS (ex_group, table_code) TABLESPACE OWMEDIUM_I]');
  EXEC_SQL(q'[CREATE UNIQUE INDEX OPT_CTR_EX_ITEMS_P ON OPT_CTR_EX_ITEMS (ex_group, parent_code, table_code) TABLESPACE OWMEDIUM_I]');
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_END2(ToReject, AppErrorText, AppErrorNumber); --Closes the current process and session if needed, will reject if ToReject was set to stnd.Yes.
END;
/