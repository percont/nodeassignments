DECLARE
  TableName dtype.Name%type := 'OPT_TMP_MENU_TREE_FILE';
  AllowRecreateOnTest dtype.Tag%type := stnd.No;
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  ToStartSession dtype.Tag%type := stnd.No;
  CommitInterval dtype.Counter%type := null; --Please only use for really big changes because, when used, the rollback in case of a process reject will not be full.
  OfficerUserId dtype.Name%type := 'OWS_A';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  ToReject dtype.Tag%type; AppErrorText dtype.LongStr%type; AppErrorNumber dtype.Counter%type; --here we can put values to get the process rolled back and rejected
  
  DeploymentLevel dtype.Counter%type;
  CreateTable dtype.Tag%type;
  CreateSequence dtype.Tag%type;
  SqlStr VARCHAR2(32000);
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    opt_ctr_util.PROCESS_MESSAGE(SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Information);
    opt_ctr_util.RELEASE_SUBPROCESS_INCREMENT;
  EXCEPTION WHEN OTHERS THEN
    opt_ctr_util.PROCESS_MESSAGE_ATX(SUBSTR(REPLACE(REPLACE('Oracle raised error:"' || SQLERRM || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Error);
    opt_ctr_util.RELEASE_SUBPROCESS_END2(stnd.Yes, SUBSTR(REPLACE(REPLACE('Failed at SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
  END;
  
  procedure CHECK_ALLOW_CREATION(
      TableNameIn dtype.Name%type
  )
  IS
    AllowRecreate dtype.Tag%type;
  BEGIN
    DeploymentLevel := nvl(opt_util.GLOBAL_PARM('DEPLOYMENT_LEVEL'), 0);
    if DeploymentLevel > 0 and AllowRecreateOnTest = stnd.Yes then
      AllowRecreate := stnd.Yes;
    end if;
    opt_ctr_util.PROCESS_MESSAGE('Table ' || TableNameIn || ' DDL check'
      || ': DeploymentLevel=' || DeploymentLevel
      || '; AllowRecreateOnTest=' || AllowRecreateOnTest
      || '; AllowRecreate=' || AllowRecreate
      , stnd.Information
    );
    
    CreateTable := stnd.Yes;
    CreateSequence := stnd.Yes;
    
    for a in(
      select *
        from user_tables
        where table_name = TableNameIn
    ) LOOP
      if AllowRecreate = stnd.Yes then
        EXEC_SQL('DROP TABLE ' || a.table_name || ' CASCADE CONSTRAINTS');
      else
        opt_ctr_util.PROCESS_MESSAGE('Table ' || a.table_name || ' exists and recreation is not allowed', stnd.Information);
        CreateTable := stnd.No;
      end if;
      EXIT;
    END LOOP;
    
    for a in(
      select *
        from all_sequences
        where sequence_name = TableNameIn || '_SEQ'
    ) LOOP
      if AllowRecreate = stnd.Yes then
        EXEC_SQL('DROP SEQUENCE ' || a.sequence_name);
      else
        opt_ctr_util.PROCESS_MESSAGE('Sequence ' || a.sequence_name || ' exists and recreation is not allowed', stnd.Information);
        CreateSequence := stnd.No;
      end if;
      EXIT;
    END LOOP;
    
  END;
  
  procedure CREATE_TIBS(
    TableNameIn dtype.Name%type
  )
  IS
  BEGIN
    if CreateSequence = stnd.Yes then
      EXEC_SQL('CREATE SEQUENCE ' || TableNameIn || '_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER');
    end if;
    if CreateTable = stnd.Yes then
      EXEC_SQL('CREATE OR REPLACE TRIGGER ' || TableNameIn || '_TIBS
BEFORE INSERT ON ' || TableNameIn || '
for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT ' || TableNameIn || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;
'     );
    end if;
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_START_P(ProcessName => FileName, ToStartSession => ToStartSession, OfficerUserId => OfficerUserId); --other parms are ProcessParms, IsUnique, ObjectType, ObjectId
  
  CHECK_ALLOW_CREATION(TableName); --initialises the CreateTable and CreateSequence, depending on whether they exist and whether recreation is possible
  if CreateTable = stnd.Yes then
    EXEC_SQL(q'[
CREATE GLOBAL TEMPORARY TABLE OPT_TMP_MENU_TREE_FILE
(   idt           VARCHAR2(255)
  , parent_idt    VARCHAR2(255)
  , seq           NUMBER(18)
  , name          VARCHAR2(255)
  , linked_to_idt VARCHAR2(255)
  , task          VARCHAR2(255)
) ON COMMIT PRESERVE ROWS
]'  );
  end if;
  --CREATE_TIBS(TableName); --checks the CreateTable and CreateSequence inside the CREATE_TIBS
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_END2(ToReject, AppErrorText, AppErrorNumber); --Closes the current process and session if needed, will reject if ToReject was set to stnd.Yes.
END;
/