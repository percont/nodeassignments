declare

/*
  Update grants utility

    2018, kost zhukov, solanteq
*/

  rc      dtype.counter   %type;
  squery  dtype.longstr   %type;
    
  procedure reject(
    msg in dtype.errormessage  %type
  )
  is
  begin
    sy_process.process_message(stnd.fatalerror, msg);
    sy_process.process_reject();
    sy_excpt.raise_exception(msg);
  end;
begin
  rc := sy_process.process_start('OPT_TABLE: create OPT_NI_OBJ_GRANTS table', null, stnd.yes);

  squery:=
'drop table opt_ni_obj_grants'; 
  execute immediate squery; 
  sy_process.process_message(stnd.information, 'Table opt_ni_obj_grants successfully dropped');
    
  select count(*)
  into rc
  from user_tables
  where table_name = 'OPT_NI_OBJ_GRANTS';
    
  if (rc = 0) then
    begin

      squery:=
'create table opt_ni_obj_grants('||   
'  officer_group_name varchar2(255),'|| 
'  officer_group_id   number(18,0),'||  
'  grantee            varchar2(32),'|| 
'  privilege          varchar2(32),'|| 
'  table_name         varchar2(32),'|| 
'  script             varchar2(4000),'||
'  type               varchar2(1),'||
'  source             varchar2(1),'||
'  status             varchar2(1),'||
'  hash               varchar2(32)'||
')'||
'tablespace OWLARGE_D';
      execute immediate squery; 
      sy_process.process_message(stnd.information, 'Table opt_ni_obj_grants successfully created');

      squery:=
'create index opt_ni_obj_grants_hash on opt_ni_obj_grants(hash)'||
'tablespace OWLARGE_I';
      execute immediate squery;
      sy_process.process_message(stnd.information, 'Index opt_ni_obj_grants_hash successfully created');

      squery:=
'create index opt_ni_obj_grants_src on opt_ni_obj_grants(source, status, type)'||
'tablespace OWLARGE_I';
      execute immediate squery;
      sy_process.process_message(stnd.information, 'Index opt_ni_obj_grants_src successfully created');

    exception when others then
      reject('something failed: ' || sqlerrm);
    end;
        
  else
    sy_process.process_message(stnd.information, 'Table OPT_NI_OBJ_GRANTS is already exist');
  end if;
    
  sy_process.process_end();
end;
/