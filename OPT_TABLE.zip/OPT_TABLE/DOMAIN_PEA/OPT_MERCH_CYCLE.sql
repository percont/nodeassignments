declare
  c dtype.Counter %type;
  sqlStr dtype.LongStr %type;
  rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE:OPT_MERCH_CYCLE - Create OPT_MERCH_CYCLE', null, stnd.No);
  
  select min(1) into c from user_tables where table_name = 'OPT_MERCH_CYCLE';
  
  if c is null then
    -- Table
    sqlStr := 'CREATE TABLE OPT_MERCH_CYCLE (
      ID                 NUMBER(18,0),
      AMND_STATE         VARCHAR2(2) DEFAULT ''A'',
      AMND_DATE          DATE,
      BANK_DATE          DATE,      
      CONTRACT_ID        NUMBER(18,0),
      BILLING_TYPE       VARCHAR2(32),
      DATE_FROM          DATE,
      DATE_TO            DATE,
      INSTITUTION_ID     NUMBER(18,0),
      CONSTRAINT PK_ID PRIMARY KEY (ID) using index tablespace OWLARGE_I
     ) tablespace OWLARGE_D
    ';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Table created.');
    
    sqlStr := 'CREATE INDEX OPT_INDX_CYCLE ON OPT_MERCH_CYCLE (CONTRACT_ID, AMND_STATE) tablespace OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index 1 created.');
    
    sqlStr := 'CREATE INDEX OPT_INDX_CYCLE2 ON OPT_MERCH_CYCLE (AMND_STATE) tablespace OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index 2 created.');
    
    sqlStr := 'CREATE INDEX OPT_INDX_CYCLE3 ON OPT_MERCH_CYCLE (INSTITUTION_ID) tablespace OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index 3 created.');
    
    sqlStr := 'CREATE SEQUENCE OPT_MERCH_CYCLE_SEQ  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 10 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOPARTITION';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Sequence created.');
  else
    stnd.process_message(stnd.Information, 'Table already exists. Skipped!');
  end if;
  
  
  --adding columns
  select count(*) into c from ALL_TAB_COLUMNS where column_name = 'ADD_INFO' and table_name = 'OPT_MERCH_CYCLE';
  
  if c = 0 then
    SqlStr := 'ALTER TABLE OPT_MERCH_CYCLE ADD ADD_INFO varchar2(500)';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
   else
    stnd.process_message(stnd.Information, 'ADD_INFO column already exists. Skipped!');
  end if;
  
  commit;
  stnd.process_end;
end;

/