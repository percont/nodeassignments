-- ssarmanova, SB-711

declare
    c       dtype.Counter   %type;
    sqlStr  dtype.LongStr   %type;
    tmpstr  dtype.name      %type;
    rc      dtype.Counter   %type;
begin
  rc := stnd.process_start('OPT_TABLE:opt_acq_paym_tables - Create OPT_ACQ_PAYMENT', null, stnd.No);
  
  select min(1) into c from user_tables where table_name = 'OPT_ACQ_PAYMENT';
  
  if c is null then
    -- Table
    sqlStr := 'CREATE TABLE OPT_ACQ_PAYMENT (
  CONTRACT_ID        NUMBER(18,0),
  CONTRACT_TYPE      VARCHAR2(1),
  PAYMENT_ID         NUMBER(18,0),
  PAYMENT_DATE       DATE,
  PAYMENT_AMOUNT     NUMBER(28,10),
  PAYMENT_CURRENCY   VARCHAR2(3),
  IBAN               VARCHAR2(64),
  ACCOUNT_NUMBER     VARCHAR2(64),
  BANK_NAME          VARCHAR2(255),
  ORDER_TYPE         VARCHAR2(1),
  STATEMENT_STATUS   VARCHAR2(1) DEFAULT ''W'',
  READY_DATE         DATE,
  CONSTRAINT PK_OPT_ACQ_PAYMENT PRIMARY KEY (PAYMENT_ID) USING INDEX TABLESPACE OWLARGE_I
) TABLESPACE OWLARGE_D 
PARTITION BY RANGE (PAYMENT_DATE) INTERVAL (NUMTODSINTERVAL(1, ''DAY'')) (
  PARTITION OPT_ACQ_PAYMENT_FIRST VALUES LESS THAN (TO_DATE(''01/01/2016'', ''DD/MM/YYYY''))
)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Table created.');
    sqlStr := 'CREATE INDEX OPT_ACQ_PAYMENT1 ON OPT_ACQ_PAYMENT (PAYMENT_DATE, CONTRACT_ID) TABLESPACE OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created.');
  else
    stnd.process_message(stnd.Information, 'Table already exists. Skipped!');
  end if;

  --adding columns
  select count(*) into c from ALL_TAB_COLUMNS where column_name = 'CREATION_DATE' and table_name = 'OPT_ACQ_PAYMENT';
  if c = 0 then
    SqlStr := 'ALTER TABLE OPT_ACQ_PAYMENT ADD CREATION_DATE DATE';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
  end if;

  select count(*) into c from ALL_TAB_COLUMNS where column_name = 'START_DATE' and table_name = 'OPT_ACQ_PAYMENT';
   if c = 0 then
    SqlStr := 'ALTER TABLE OPT_ACQ_PAYMENT ADD START_DATE DATE';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
  end if;

    select count(*) into c from ALL_TAB_COLUMNS where column_name = 'READY_DATE' and table_name = 'OPT_ACQ_PAYMENT';
   if c = 0 then
    SqlStr := 'ALTER TABLE OPT_ACQ_PAYMENT ADD READY_DATE DATE';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
  end if;

    select count(*) into c from ALL_TAB_COLUMNS where column_name = 'CHECK_DATE' and table_name = 'OPT_ACQ_PAYMENT';
   if c = 0 then
    SqlStr := 'ALTER TABLE OPT_ACQ_PAYMENT ADD CHECK_DATE DATE';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
  end if;
  
  select count(1) into c
  from user_sequences
  where sequence_name = 'OPT_ACQ_PAYMENT_SEQ';
  if (c = 0) then
    sqlStr := 'create sequence OPT_ACQ_PAYMENT_SEQ  start with 1 increment by 1 cache 1000';
    execute immediate sqlStr;
    stnd.process_message(stnd.information, 'Sequence OPT_ACQ_PAYMENT_SEQ created.');
  end if;
  
  select count(1) into c
  from all_tab_columns
  where table_name = 'OPT_ACQ_PAYMENT'
    and column_name = 'ID';
  if (c = 0) then
    sqlStr := 'alter table OPT_ACQ_PAYMENT add (ID number(18) default null)';
    execute immediate sqlStr;
    stnd.process_message(stnd.information, 'Column ID added');
  else
    select data_default
    into tmpstr
    from all_tab_columns
    where table_name = 'OPT_ACQ_PAYMENT'
      and column_name = 'ID';
    if (tmpstr is null or tmpstr not like '%OPT_ACQ_PAYMENT_SEQ%') then
      sqlStr := 'alter table OPT_ACQ_PAYMENT modify (ID number(18) default OPT_ACQ_PAYMENT_SEQ.nextval)';
      execute immediate sqlStr;
      stnd.process_message(stnd.information, 'Column ID modified: [' || sqlStr || ']');
    end if;
  end if;
  
  select count(1) into c
  from user_indexes
  where index_name = 'OPT_ACQ_PAYMENT_ID';
  if (c = 0) then
    sqlStr := 'create index OPT_ACQ_PAYMENT_ID on OPT_ACQ_PAYMENT (ID) tablespace OWLARGE_I parallel 16';
    execute immediate sqlStr;
    execute immediate 'alter index OPT_ACQ_PAYMENT_ID noparallel';
    stnd.process_message(stnd.information, 'Index OPT_ACQ_PAYMENT_ID added');
  end if;
  
  stnd.process_end;
end;
/

declare
    c       dtype.Counter   %type;
    sqlStr  dtype.LongStr   %type;
    tmpstr  dtype.name      %type;
    rc      dtype.Counter   %type;
begin
  rc := stnd.process_start('OPT_TABLE:opt_acq_paym_tables - Create OPT_ACQ_PAYMENT_DATA', null, stnd.No);
  
  select min(1) into c from user_tables where table_name = 'OPT_ACQ_PAYMENT_DATA';
  
  if c is null then
    -- Table
    sqlStr := 'CREATE TABLE OPT_ACQ_PAYMENT_DATA (
  CONTRACT_ID        NUMBER(18,0),
  PAYMENT_ID         NUMBER(18,0),
  PAYMENT_DATE       DATE,
  ENTRY_ID           NUMBER(18,0),
  ENTRY_TYPE         VARCHAR2(1),
  ENTRY_DIRECTION    VARCHAR2(1),
  ENTRY_AMOUNT       NUMBER(28,10),
  ENTRY_CURR         VARCHAR2(3),
  PAYM_AMOUNT        NUMBER(28,10),
  PAYM_CURR          VARCHAR2(3),
  GL_TRACE_ID        NUMBER(18,0),
  TRANS_MTR_ID	     NUMBER(18,0),
  TRANS_DOC_ID       NUMBER(18,0),
  TRANS_PARTY_ID     NUMBER(18,0),
  IS_PART_OF_PAYMENT VARCHAR2(1),
  RR_RELEASE_DATE    DATE
) TABLESPACE OWLARGE_D
PARTITION BY RANGE (PAYMENT_DATE) INTERVAL (NUMTODSINTERVAL(1, ''DAY'')) (
  PARTITION OPT_ACQ_DATA_FIRST VALUES LESS THAN (TO_DATE(''01/01/2016'', ''DD/MM/YYYY''))
)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Table created.');
    sqlStr := 'CREATE INDEX OPT_ACQ_PAYMENT_DATA1 ON OPT_ACQ_PAYMENT_DATA (CONTRACT_ID) LOCAL TABLESPACE OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created.');
    
    sqlStr := 'CREATE INDEX OPT_ACQ_PAYMENT_DATA2 ON OPT_ACQ_PAYMENT_DATA (PAYMENT_ID) LOCAL TABLESPACE OWLARGE_I';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created.');
  else
    stnd.process_message(stnd.Information, 'Table already exists. Skipped!');
  end if;
  
  select count(1) into c
  from user_sequences
  where sequence_name = 'OPT_ACQ_PAYMENT_DATA_SEQ';
  if (c = 0) then
    sqlStr := 'create sequence OPT_ACQ_PAYMENT_DATA_SEQ start with 1 increment by 1 cache 1000';
    execute immediate sqlStr;
    stnd.process_message(stnd.information, 'Sequence OPT_ACQ_PAYMENT_DATA_SEQ created.');
  end if;
  
  select count(1) into c
  from all_tab_columns
  where table_name = 'OPT_ACQ_PAYMENT_DATA'
    and column_name = 'ID';
  if (c = 0) then
    sqlStr := 'alter table OPT_ACQ_PAYMENT_DATA add (ID number(18) default null)';
    execute immediate SqlStr;
    stnd.process_message(stnd.information, 'Column ID added');
  else
    select data_default
    into tmpstr
    from all_tab_columns
    where table_name = 'OPT_ACQ_PAYMENT_DATA'
      and column_name = 'ID';
    if (tmpstr is null or tmpstr not like '%OPT_ACQ_PAYMENT_DATA_SEQ%') then
      sqlStr := 'alter table OPT_ACQ_PAYMENT_DATA modify (ID number(18) default OPT_ACQ_PAYMENT_DATA_SEQ.nextval)';
      execute immediate sqlStr;
      stnd.process_message(stnd.information, 'Column ID modified: [' || sqlStr || ']');
    end if;
  end if;
  
  /*select count(1) into c
  from user_indexes
  where index_name = 'OPT_ACQ_PAYMENT_DATA_ID';
  if (c = 0) then
    sqlStr := 'create index OPT_ACQ_PAYMENT_DATA_ID on OPT_ACQ_PAYMENT_DATA (ID) tablespace OWLARGE_I parallel 16';
    execute immediate sqlStr;
    execute immediate 'alter index OPT_ACQ_PAYMENT_DATA_ID noparallel';
    stnd.process_message(stnd.information, 'Index OPT_ACQ_PAYMENT_DATA_ID added');
  end if;*/
  
  stnd.process_end;
end;
/