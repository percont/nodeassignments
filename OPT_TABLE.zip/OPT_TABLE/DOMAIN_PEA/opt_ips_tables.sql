-- create tables to be used in opt_chargeback
declare
c dtype.Counter %type;
sqlStr dtype.LongStr %type;
rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE: create opt_ips_* tables', null, stnd.No);
  select min(1) into c from user_tables where table_name = 'OPT_IPS_DOC';
  if c is null then
     sqlStr := 'CREATE TABLE opt_ips_doc AS 
     SELECT * FROM doc WHERE rownum < 1';
     execute immediate sqlStr;          
     sqlStr := 'CREATE INDEX OPT_IPS_DOC_BY_ARN ON OPT_IPS_DOC (ACQ_REF_NUMBER, OUTWARD_STATUS, AMND_STATE)';
     execute immediate sqlStr;          
     stnd.process_message(stnd.Information, 'Table opt_ips_doc created.');
  end if;   
  select min(1) into c from user_tables where table_name = 'OPT_IPS_ORIGINAL_DOC';
  if c is null then
     sqlStr := 'CREATE TABLE opt_ips_original_doc AS
     SELECT * FROM original_doc WHERE rownum < 1';
     execute immediate sqlStr;         
     sqlStr := 'CREATE INDEX OPT_IPS_ORIGINAL_DOC_BY_ID ON OPT_IPS_ORIGINAL_DOC (ID)';
     execute immediate sqlStr;          
     stnd.process_message(stnd.Information, 'Table opt_ips_original_doc created.');
  end if;
  select min(1) into c from user_tables where table_name = 'OPT_IPS_FILE_INFO';
  if c is null then
     sqlStr := 'CREATE TABLE opt_ips_file_info AS
     SELECT * FROM file_info WHERE rownum < 1';
     execute immediate sqlStr;         
     sqlStr := 'CREATE INDEX OPT_IPS_FILE_INFO_BY_ID ON OPT_IPS_FILE_INFO (ID)';
     execute immediate sqlStr;          
     stnd.process_message(stnd.Information, 'Table opt_ips_file_info created.');
  end if;
  stnd.process_end;
end;
/
  