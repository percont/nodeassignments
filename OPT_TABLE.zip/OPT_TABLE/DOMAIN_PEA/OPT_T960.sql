declare
  TableCount dtype.Counter%type;
  SqlStr DTYPE.XMLString%type;
  ProcRc dtype.Counter%type;
  ToRecreate CONSTANT dtype.Tag%type := 'N'; -- TODO Need to change before go-live!
  IsTestEnv dtype.Tag%type;
  TableName dtype.Name %type := 'OPT_T960';
begin 
      ProcRc := stnd.PROCESS_START('DDL: Table: CREATE '|| TableName, null, stnd.No);

  IsTestEnv := opt_pei_forms.IS_TEST_ENV;
  select count(*) into TableCount from user_tables where table_name = TableName;

  if TableCount > 0 and ToRecreate = stnd.Yes then

    BEGIN
      SqlStr := 'drop sequence '|| TableName || '_SEQ';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'alter table '|| TableName ||' drop primary key cascade';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'drop table '|| TableName || ' cascade constraints';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END; 

  elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table '|| TableName || ' does exist and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
  
  -- Table
  SqlStr := '
    Create table '|| TableName || ' (
  AMND_STATE                VARCHAR2(1)     DEFAULT ''A'',
  AMND_DATE                 DATE            DEFAULT sysdate,
  AMND_OFFICER              NUMBER(18)      DEFAULT 1,
  BANK_DATE                 DATE,
  FILE_ID                   VARCHAR2(50),
  MATCH_STATUS              VARCHAR2(1)     DEFAULT ''N'',
  DOC__OID		    NUMBER(18),
  ID                        NUMBER(18)      NOT NULL,
  RECORD_COUNT_FOR_ICA      NUMBER(13),
  ISO_ACQUIRER_ICA          NUMBER (06),
  ISO_FORWARD_INST_ID       NUMBER(06),
  ISO_CARDHOLDER_NBR        VARCHAR2(19),
  ISO_TRANSACTION_AMT       NUMBER (10),
  ISO_FORWARD_INST_ID_ONLY  VARCHAR2(06),
  ISO_AUTH_NUMBER           VARCHAR2(06),
  ISO_AUTH_RESPONSE         VARCHAR2(02),
  ISO_AUTH_ADDL_DATA        VARCHAR2(25),
  ISO_CARDHOLDER_EXPT       VARCHAR2(04),
  ISO_POS_DEVICE_TYPE       VARCHAR2(03),
  ISO_TRACK_TWO_DATA        VARCHAR2(37),
  ISO_TRACK_ONE_DATA        VARCHAR2(76),
  ISO_TRANSACTION_TYPE      VARCHAR2(01),
  ISO_AVS_REQUEST_TAG       VARCHAR2(02),
  ISO_AVS_REQUEST_LGTH      VARCHAR2(02),
  ISO_AVS_REQUEST_CODE      VARCHAR2(02),
  ISO_AVS_RESPONSE_TAG      VARCHAR2(02),
  ISO_AVS_RESPONSE_LGTH     VARCHAR2(02),
  ISO_AVS_RESPONSE_CODE     VARCHAR2(01),
  ISO_POS_DATA              VARCHAR2(26),
  ISO_FIN_NETWORK_CODE      VARCHAR2(03),
  ISO_PROCESSING_CODE       VARCHAR2(06),
  ISO_DATE_TIME_XMIT        VARCHAR2(10),
  ISO_MERCHANT_TYPE         VARCHAR2(04),
  ISO_COUNTRY_CODE          VARCHAR2(03),
  ISO_POS_PIN_CAPTURE       VARCHAR2(02),
  ISO_RETRIEVEL_REFNO       VARCHAR2(12),
  ISO_ID_TERMINAL           VARCHAR2(08),
  ISO_CARD_ACCEPTOR         VARCHAR2(15),
  ISO_ADDTL_DATA            VARCHAR2(03),
  ISO_BKNT_DATA             VARCHAR2(09),
  ISO_MERCHANT_ID           VARCHAR2(16),
  ISO_TRANS_DATE            VARCHAR2(04),
  ISO_ISS_UP_ICA            VARCHAR2(06),
  ISO_STATE_CODE            VARCHAR2(02),
  ISO_BL_IC_SEQ_NO          VARCHAR2(08),
  ISO_IC_MAG_CC             VARCHAR2(01),
  ISO_DE48_TAG87_PRESENT    VARCHAR2(01),
  ISO_DE48_TAG88_PRESENT    VARCHAR2(01),
  ISO_DE48_TAG89_VALUE      VARCHAR2(01),
  ISO_AVS2_SHIP2_NAME       VARCHAR2(27),
  ISO_AVS2_SHIP2_CO_NAME    VARCHAR2(27),
  ISO_AVS2_SHIP2_ADD_1      VARCHAR2(32),
  ISO_AVS2_SHIP2_ADD_2      VARCHAR2(32),
  ISO_AVS2_SHIP2_CITY       VARCHAR2(15),
  ISO_AVS2_SHIP2_STATE      VARCHAR2(02),
  ISO_AVS2_SHIP2_POSTAL     VARCHAR2(09),
  ISO_AVS2_SHIP2_COUNTRY    VARCHAR2(03),
  ISO_AVS2_CURRENCY_CODE    VARCHAR2(03),
  ISO_AVS2_RESP_CODE        VARCHAR2(02),
  ISO_AVS2_PHONE_NUM        VARCHAR2(10),
  ISO_AVS2_FRAUD_ALERT      VARCHAR2(01),
  ISO_AVS2_RUSH_ORDER       VARCHAR2(01),
  ISO_DE4_TRN_AMT           NUMBER(13),
  ISO_DE5_SETL_AMT          NUMBER(13),
  ISO_DE6_CRDHLD_BIL_AMT    NUMBER(13),
  ISO_DE9_SETL_CNV_RTE      VARCHAR2(08),
  ISO_DE10_CRDHLD_CNV_RTE   VARCHAR2(08),
  ISO_CNV_DTE_CCYYMMDD      VARCHAR2(08),
  ISO_DE49_TRN_CUR_CDE      VARCHAR2(03),
  ISO_DE50_SETL_CUR_CDE     VARCHAR2(03),
  ISO_DE51_CRDHLD_CUR_CDE   VARCHAR2(03),
  ISO_DE48_TAG2_FLD1        VARCHAR2(02),
  ISO_DE43_MRCH_NAME        VARCHAR2(22),
  ISO_DE43_MRCH_CITY        VARCHAR2(13),
  ISO_DE43_MRCH_ST_CNTY     VARCHAR2(03),
  ISO_DE48_TAG84            VARCHAR2(02),
  ISO_MEMBER_DATA           VARCHAR2(99),
  ISO_PRIVATE_DATA          VARCHAR2(100),
  ISO_TIME_LOCAL_TRANS      NUMBER(06),
  ISO_DATE_LOCAL_TRANS      NUMBER(04),
  ISO_DE48_SE42_LEN3        VARCHAR2(03),
  ISO_DE48_SE42_SF2_SF3     VARCHAR2(04),
  ISO_DE48_SE33_SF1         VARCHAR2(01),
  ISO_DE48_SE33_SF2         VARCHAR2(19),
  ISO_DE48_SE33_SF5         VARCHAR2(02),
  ISO_DE48_SE33_SF6         VARCHAR2(11),
  ADD_INFO                  VARCHAR2(1024) 
    ) TABLESPACE OWMEDIUM_D
    PARTITION BY RANGE (BANK_DATE)
    INTERVAL(NUMTODSINTERVAL(1,''DAY''))
    (PARTITION ST_TEST_TAB_PART VALUES LESS THAN (TO_DATE(''20100101'', ''YYYYMMDD'', ''NLS_CALENDAR=GREGORIAN'')))
PCTUSED    0
PCTFREE    5
INITRANS   1
LOGGING 
NOCOMPRESS 
NOCACHE
MONITORING';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table created.');
  
  -- Indexes Unique
  SqlStr := 'CREATE UNIQUE INDEX PK_'|| TableName || ' ON '|| TableName || '(ID) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  -- Indexes
  SqlStr := 'CREATE INDEX '|| TableName || '_FILE_D ON '|| TableName || '(FILE_ID,BANK_DATE) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  -- Indexes
  SqlStr := 'CREATE INDEX '|| TableName || '_MATCH_R ON '|| TableName || '(AMND_STATE, MATCH_STATUS, DOC__OID) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');
 
  -- Indexes
  SqlStr := 'CREATE INDEX '|| TableName || '_MATCH_D ON '|| TableName || '(AMND_STATE, ISO_CARDHOLDER_NBR, ISO_AUTH_NUMBER, ISO_DATE_TIME_XMIT) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');
  
  -- Indexes
  SqlStr := 'CREATE INDEX '|| TableName || '_MATCH_S ON '|| TableName || '(AMND_STATE, AMND_DATE, ISO_CARDHOLDER_NBR, ISO_AUTH_NUMBER) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

   -- Sequence
  SqlStr := 'CREATE SEQUENCE '|| TableName || '_SEQ START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999999999999 MINVALUE 1 NOCYCLE CACHE 20 NOORDER';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Sequence created.');

  -- Trigger
  SqlStr := 'CREATE OR REPLACE TRIGGER '|| TableName || '_TIBS
  BEFORE INSERT ON '|| TableName || '
  for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT '|| TableName || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Trigger created.');
  <<SKIP>>
  FOR a IN (SELECT *
              FROM all_tab_columns
             WHERE table_name = TableName
               AND column_name = 'ADD_INFO') LOOP
    IF a.CHAR_LENGTH != '3900' THEN
      SqlStr := 'ALTER TABLE ' || TableName || ' MODIFY (ADD_INFO varchar2(3900)' || ')';
      EXECUTE IMMEDIATE SqlStr;
      sy_process.process_message(stnd.information
                                ,'Table ' || TableName || ' successfully updated');
    END IF;
  END LOOP;
  stnd.PROCESS_END;
end;
/
