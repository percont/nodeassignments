declare
  TableCount dtype.Counter%type;
  SqlStr dtype.LongStr%type;
  ProcRc dtype.Counter%type;
  ToRecreate CONSTANT dtype.Tag%type := 'N'; -- TODO Need to change before go-live!
  IsTestEnv dtype.Tag%type;
  TableName dtype.Name %type := 'OPT_AIRLINE_RULE_SY';
begin 
      ProcRc := stnd.PROCESS_START('DDL: Table: CREATE '|| TableName, null, stnd.No);

  IsTestEnv := opt_pei_forms.IS_TEST_ENV;
  select count(*) into TableCount from user_tables where table_name = TableName;

  if TableCount > 0 and ToRecreate = stnd.Yes then

    BEGIN
      SqlStr := 'drop sequence '|| TableName || '_SEQ';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'alter table '|| TableName ||' drop primary key cascade';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'drop table '|| TableName || ' cascade constraints';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END; 

  elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table '|| TableName || ' does exist and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
  
  -- Table
  SqlStr := '
    Create table '|| TableName || ' (
  AMND_STATE                VARCHAR2(1)     DEFAULT ''A'',
  AMND_DATE                 DATE            DEFAULT sysdate,
  AMND_OFFICER              NUMBER(18)      DEFAULT 1,
  ID                        NUMBER(18),
  PREV__ID					NUMBER(18),
  RULE_NUMBER               VARCHAR2(255),
  IF_CHANNEL                VARCHAR2(255),
  IF_MERCHANT_CODE          VARCHAR2(255),
  IF_MCC                    VARCHAR2(255),
  IF_CARDHOLDER_COUNTRY     VARCHAR2(255),
  IF_CROSS_BORDER           VARCHAR2(255),
  IF_CARD_PRESENT           VARCHAR2(32),
  IF_CARD_TYPE              VARCHAR2(255),
  IF_CARD_CATEGORY          VARCHAR2(32),
  IF_IPS_CHANNEL_PRODUCT    VARCHAR2(255),
  IF_AIRPORT_COUNTRY_CODE   VARCHAR2(255),
  IF_EEA_FLAG               VARCHAR2(1),
  MASTERCARD_ICA            VARCHAR2(32),
  MASTERCARD_BIN            VARCHAR2(32),
  VISA_BIN                  VARCHAR2(32),
  MERCHANT_COUNTRY          VARCHAR2(255),
  MERCHANT_CITY             VARCHAR2(255),
  MERCHANT_ZIP_CODE         VARCHAR2(255),
  MERCHANT_STATE            VARCHAR2(255),
  MERCHANT_ADDRESS          VARCHAR2(255),
  PRIORITY                  NUMBER(3),
  ADD_INFO                  VARCHAR2(3900)  DEFAULT NULL,
  DESCRIPTON                VARCHAR2(3900)  DEFAULT NULL,
  RULE_TYPE					VARCHAR2(32),  
  IS_ACTIVE                 VARCHAR2(1)
   ) TABLESPACE OWMEDIUM_D
	';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table created.');
  
  -- Indexes
  SqlStr := 'CREATE UNIQUE INDEX PK_'|| TableName || ' ON '|| TableName || '(ID) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  SqlStr := 'CREATE INDEX '|| TableName || '_BASE ON '|| TableName || '(AMND_STATE, IF_CHANNEL) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');
  
  SqlStr := 'CREATE INDEX '|| TableName || '_RULE ON '|| TableName || '(RULE_NUMBER) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  SqlStr := 'CREATE INDEX '|| TableName || '_ACTIVE ON '|| TableName || '(IS_ACTIVE) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  -- Sequence
  SqlStr := 'CREATE SEQUENCE '|| TableName || '_SEQ START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999999999999 MINVALUE 1 NOCYCLE CACHE 20 NOORDER';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Sequence created.');

  -- Trigger
  SqlStr := 'CREATE OR REPLACE TRIGGER '|| TableName || '_TIBS
  BEFORE INSERT ON '|| TableName || '
  for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT '|| TableName || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Trigger created.');

  <<SKIP>>
  stnd.PROCESS_END;
commit;
end;
/