DECLARE
  TableName dtype.Name%type := 'OPT_ARC_CONTRACT';
  AllowRecreateOnTest dtype.Tag%type := stnd.No; --or stnd.Yes
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  ToStartSession dtype.Tag%type := stnd.No;
  CommitInterval dtype.Counter%type := null; --Please only use for really big changes because, when used, the rollback in case of a process reject will not be full.
  OfficerUserId dtype.Name%type := 'OWS_A';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  ToReject dtype.Tag%type; AppErrorText dtype.LongStr%type; AppErrorNumber dtype.Counter%type; --here we can put values to get the process rolled back and rejected
  
  DeploymentLevel dtype.Counter%type;
  CreateTable dtype.Tag%type;
  CreateSequence dtype.Tag%type;
  SqlStr VARCHAR2(32000);
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    opt_ctr_util.PROCESS_MESSAGE(SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Information);
    opt_ctr_util.RELEASE_SUBPROCESS_INCREMENT;
  EXCEPTION WHEN OTHERS THEN
    opt_ctr_util.PROCESS_MESSAGE_ATX(SUBSTR(REPLACE(REPLACE('Oracle raised error:"' || SQLERRM || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Error);
    opt_ctr_util.RELEASE_SUBPROCESS_END2(stnd.Yes, SUBSTR(REPLACE(REPLACE('Failed at SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
  END;
  
  procedure CHECK_ALLOW_CREATION(
      TableNameIn dtype.Name%type
  )
  IS
    AllowRecreate dtype.Tag%type;
  BEGIN
    DeploymentLevel := nvl(opt_util.GLOBAL_PARM('DEPLOYMENT_LEVEL'), 0);
    if DeploymentLevel > 0 and AllowRecreateOnTest = stnd.Yes then
      AllowRecreate := stnd.Yes;
    end if;
    opt_ctr_util.PROCESS_MESSAGE('Table ' || TableNameIn || ' DDL check'
      || ': DeploymentLevel=' || DeploymentLevel
      || '; AllowRecreateOnTest=' || AllowRecreateOnTest
      || '; AllowRecreate=' || AllowRecreate
      , stnd.Information
    );
    
    CreateTable := stnd.Yes;
    CreateSequence := stnd.Yes;
    
    for a in(
      select *
        from user_tables
        where table_name = TableNameIn
    ) LOOP
      if AllowRecreate = stnd.Yes then
        EXEC_SQL('DROP TABLE ' || a.table_name || ' CASCADE CONSTRAINTS');
      else
        opt_ctr_util.PROCESS_MESSAGE('Table ' || a.table_name || ' exists and recreation is not allowed', stnd.Information);
        CreateTable := stnd.No;
      end if;
      EXIT;
    END LOOP;
    
    for a in(
      select *
        from all_sequences
        where sequence_name = TableNameIn || '_SEQ'
    ) LOOP
      if AllowRecreate = stnd.Yes then
        EXEC_SQL('DROP SEQUENCE ' || a.sequence_name);
      else
        opt_ctr_util.PROCESS_MESSAGE('Sequence ' || a.sequence_name || ' exists and recreation is not allowed', stnd.Information);
        CreateSequence := stnd.No;
      end if;
      EXIT;
    END LOOP;
    
  END;
  
  procedure CREATE_TIBS(
    TableNameIn dtype.Name%type
  )
  IS
  BEGIN
    if CreateSequence = stnd.Yes then
      EXEC_SQL('CREATE SEQUENCE ' || TableNameIn || '_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER');
    end if;
    if CreateTable = stnd.Yes then
      EXEC_SQL('CREATE OR REPLACE TRIGGER ' || TableNameIn || '_TIBS
  BEFORE INSERT ON ' || TableNameIn || '
  for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT ' || TableNameIn || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;
'     );
    end if;
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_START_P(ProcessName => FileName, ToStartSession => ToStartSession, OfficerUserId => OfficerUserId); --other parms are ProcessParms, IsUnique, ObjectType, ObjectId
  
  CHECK_ALLOW_CREATION(TableName); --initialises the CreateTable and CreateSequence, depending on whether they exist and whether recreation is possible
  if CreateTable = stnd.Yes then
    EXEC_SQL(q'[
    create table OPT_ARC_CONTRACT (
      ID                    NUMBER(18)              NOT NULL,
      FI_CODE               VARCHAR2(3 CHAR)        NOT NULL,
      REC_EXP_DATE          DATE                    NOT NULL,
      CON_CAT               VARCHAR2(1 CHAR)        NOT NULL,
      CONTRACT_NUMBER       VARCHAR2(64 CHAR)       NOT NULL,
      PARENT_NUMBER         VARCHAR2(64 CHAR),
      NEXT_CONTRACT_NUMBER  VARCHAR2(64 CHAR),
      NEXT_CONTRACT_DATE    DATE,
      BCODE1                VARCHAR2(1 CHAR),
      BCODE1_DATE           DATE,
      BCODE2                VARCHAR2(1 CHAR),
      BCODE2_DATE           DATE,
      OPEN_DATE             DATE,
      ACTIV_DATE            DATE,
      CLOSE_DATE            DATE,
      DLQ_LEVEL             NUMBER(3),
      CLIENT_NUMBER         VARCHAR2(64 CHAR),
      CLIENT_REG_NUMBER     VARCHAR2(64 CHAR),
      FIRST_NAME            VARCHAR2(64 CHAR),
      LAST_NAME             VARCHAR2(64 CHAR),
      BIRTH_DATE            DATE,
      MOBILE_NUM            VARCHAR2(64 CHAR),
      TAG_1                 VARCHAR2(1 CHAR),
      TAG_2                 VARCHAR2(1 CHAR),
      TAG_3                 VARCHAR2(1 CHAR),
      STRING_1              VARCHAR2(3900 CHAR),
      STRING_2              VARCHAR2(3900 CHAR),
      STRING_3              VARCHAR2(3900 CHAR),
      STRING_4              VARCHAR2(3900 CHAR),
      STRING_5              VARCHAR2(3900 CHAR),
      STRING_6              VARCHAR2(3900 CHAR),
      ID_1                  NUMBER(18),
      ID_2                  NUMBER(18),
      ID_3                  NUMBER(18),
      AMOUNT_1              NUMBER(28,10),
      AMOUNT_2              NUMBER(28,10),
      AMOUNT_3              NUMBER(28,10),
      DATE_1                DATE,
      DATE_2                DATE,
      DATE_3                DATE,
      CONTRACT_STATUS       VARCHAR2(1 CHAR),
      CONTRACT_ROLE         VARCHAR2(1 CHAR)
    ) TABLESPACE OWLARGE_D
]'  );
    
    EXEC_SQL(q'[CREATE INDEX OPT_ARC_CONTRACT_CLIENT_NUMBER ON OPT_ARC_CONTRACT (CLIENT_NUMBER) TABLESPACE OWLARGE_I]');
    EXEC_SQL(q'[CREATE INDEX OPT_ARC_CONTRACT_CLIENT_REG ON OPT_ARC_CONTRACT (CLIENT_REG_NUMBER) TABLESPACE OWLARGE_I]');
    EXEC_SQL(q'[CREATE INDEX OPT_ARC_CONTRACT_CONTRACT_NR ON OPT_ARC_CONTRACT (CONTRACT_NUMBER) TABLESPACE OWLARGE_I]');
    EXEC_SQL(q'[CREATE INDEX OPT_ARC_CONTRACT_FI_CODE ON OPT_ARC_CONTRACT (FI_CODE) TABLESPACE OWLARGE_I]');
    EXEC_SQL(q'[CREATE INDEX OPT_ARC_CONTRACT_NEXT_CONTRACT ON OPT_ARC_CONTRACT (NEXT_CONTRACT_NUMBER) TABLESPACE OWLARGE_I]');
    EXEC_SQL(q'[CREATE INDEX OPT_ARC_CONTRACT_PARENT_NR ON OPT_ARC_CONTRACT (PARENT_NUMBER) TABLESPACE OWLARGE_I]');
    EXEC_SQL(q'[CREATE UNIQUE INDEX PK_OPT_ARC_CONTRACT ON OPT_ARC_CONTRACT (ID) TABLESPACE OWLARGE_I]');
    EXEC_SQL(q'[ALTER TABLE OPT_ARC_CONTRACT ADD (CONSTRAINT PK_OPT_ARC_CONTRACT PRIMARY KEY (ID) USING INDEX PK_OPT_ARC_CONTRACT ENABLE VALIDATE)]');
  end if;
  
  CREATE_TIBS(TableName); --checks the CreateTable and CreateSequence inside the CREATE_TIBS
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_END2(ToReject, AppErrorText, AppErrorNumber); --Closes the current process and session if needed, will reject if ToReject was set to stnd.Yes.
END;
/