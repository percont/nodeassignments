DECLARE
  TableName dtype.Name%type := 'OPT_SDM_DE_OBJ_APPR';
  AllowRecreateOnTest dtype.Tag%type := stnd.No; --or stnd.Yes
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  ToStartSession dtype.Tag%type := stnd.No;
  CommitInterval dtype.Counter%type := null; --Please only use for really big changes because, when used, the rollback in case of a process reject will not be full.
  OfficerUserId dtype.Name%type := 'OWS_A';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  ToReject dtype.Tag%type; AppErrorText dtype.LongStr%type; AppErrorNumber dtype.Counter%type; --here we can put values to get the process rolled back and rejected
  
  DeploymentLevel dtype.Counter%type;
  CreateTable dtype.Tag%type;
  CreateSequence dtype.Tag%type;
  SqlStr VARCHAR2(32000);
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    opt_calc.PROCESS_MESSAGE(SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Information);
    opt_ctr_util.RELEASE_SUBPROCESS_INCREMENT;
  EXCEPTION WHEN OTHERS THEN
    opt_ctr_util.PROCESS_MESSAGE_ATX(SUBSTR(REPLACE(REPLACE('Oracle raised error:"' || SQLERRM || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Error);
    opt_ctr_util.RELEASE_SUBPROCESS_END2(stnd.Yes, SUBSTR(REPLACE(REPLACE('Failed at SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
  END;
  
  procedure CHECK_ALLOW_CREATION(
      TableNameIn dtype.Name%type
  )
  IS
    AllowRecreate dtype.Tag%type;
  BEGIN
    DeploymentLevel := nvl(opt_util.GLOBAL_PARM('DEPLOYMENT_LEVEL'), 0);
    if DeploymentLevel > 0 and AllowRecreateOnTest = stnd.Yes then
      AllowRecreate := stnd.Yes;
    end if;
    opt_calc.PROCESS_MESSAGE('Table ' || TableNameIn || ' DDL check'
      || ': DeploymentLevel=' || DeploymentLevel
      || '; AllowRecreateOnTest=' || AllowRecreateOnTest
      || '; AllowRecreate=' || AllowRecreate
      , stnd.Information
    );
    
    CreateTable := stnd.Yes;
    CreateSequence := stnd.Yes;
    
    for a in(
      select *
        from user_tables
        where table_name = TableNameIn
    ) LOOP
      if AllowRecreate = stnd.Yes then
        EXEC_SQL('DROP TABLE ' || a.table_name || ' CASCADE CONSTRAINTS');
      else
        opt_calc.PROCESS_MESSAGE('Table ' || a.table_name || ' exists and recreation is not allowed', stnd.Information);
        CreateTable := stnd.No;
      end if;
      EXIT;
    END LOOP;
    
    for a in(
      select *
        from all_sequences
        where sequence_name = TableNameIn || '_SEQ'
    ) LOOP
      if AllowRecreate = stnd.Yes then
        EXEC_SQL('DROP SEQUENCE ' || a.sequence_name);
      else
        opt_calc.PROCESS_MESSAGE('Sequence ' || a.sequence_name || ' exists and recreation is not allowed', stnd.Information);
        CreateSequence := stnd.No;
      end if;
      EXIT;
    END LOOP;
    
  END;
  
  procedure CREATE_TIBS(
    TableNameIn dtype.Name%type
  )
  IS
  BEGIN
    if CreateSequence = stnd.Yes then
      EXEC_SQL('CREATE SEQUENCE ' || TableNameIn || '_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER');
    end if;
    if CreateTable = stnd.Yes then
      EXEC_SQL('CREATE OR REPLACE TRIGGER ' || TableNameIn || '_TIBS
BEFORE INSERT ON ' || TableNameIn || '
for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT ' || TableNameIn || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;
'     );
    end if;
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_START_P(ProcessName => FileName, ToStartSession => ToStartSession, OfficerUserId => OfficerUserId); --other parms are ProcessParms, IsUnique, ObjectType, ObjectId
  
  CHECK_ALLOW_CREATION(TableName); --initialises the CreateTable and CreateSequence, depending on whether they exist and whether recreation is possible
  if CreateTable = stnd.Yes then
    EXEC_SQL(q'[
CREATE TABLE OPT_SDM_DE_OBJ_APPR(
    fi_id                     NUMBER(18)          NOT NULL
  , sdm_channel               VARCHAR2(64 CHAR)   NOT NULL
  , obj_root                  VARCHAR2(32 CHAR)   NOT NULL
  , de_code                   VARCHAR2(65 CHAR)   NOT NULL
  , fi_code                   VARCHAR2(32 CHAR)   NOT NULL
  , base_class                VARCHAR2(32 CHAR)   NOT NULL
  , obj_code                  VARCHAR2(32 CHAR)   
  , obj_name                  VARCHAR2(64 CHAR)   
  , obj_path                  VARCHAR2(4000 CHAR) 
  , include_level             NUMBER              
  , de_class                  VARCHAR2(32 CHAR)   NOT NULL
  , de_class_name             VARCHAR2(64 CHAR)   
  , de_name                   VARCHAR2(130 CHAR)  
  , de_extcode                VARCHAR2(64 CHAR)   
  , de_comments               VARCHAR2(4000 CHAR) 
  , s_table                   VARCHAR2(32 CHAR)   
  , s_type                    VARCHAR2(32 CHAR)   
  , s_field                   VARCHAR2(32 CHAR)   
  , s_tag_name                VARCHAR2(32 CHAR)   
  , s_to_string               VARCHAR2(32 CHAR)   
  , data_type                 VARCHAR2(32 CHAR)   
  , is_internal               VARCHAR2(1 CHAR)    
  , is_mand                   VARCHAR2(1 CHAR)    
  , min_len                   NUMBER(9)           
  , max_len                   NUMBER(9)           
  , is_list                   VARCHAR2(1 CHAR)    
  , list_class                VARCHAR2(64 CHAR)   
  , list_parms                VARCHAR2(3900 CHAR) 
  , getter_parm               VARCHAR2(3900 CHAR) 
  , setter_parm               VARCHAR2(3900 CHAR) 
  , regex_mask                VARCHAR2(3900 CHAR) 
  , validator_list            VARCHAR2(3900 CHAR) 
  , replacer_list             VARCHAR2(3900 CHAR) 
  , defaulting_type           VARCHAR2(64 CHAR)   
  , defaulting_parm           VARCHAR2(3900 CHAR) 
  , add_parms                 VARCHAR2(3900 CHAR) 
  , data_validation_comments  VARCHAR2(3900 CHAR) 
  , input_mode                VARCHAR2(32 CHAR)   
  , tvf_field                 VARCHAR2(8 CHAR)    
  , CONSTRAINT PK_OPT_SDM_DE_OBJ_APPR PRIMARY KEY(fi_id, sdm_channel, obj_root, de_code) USING INDEX TABLESPACE OWSTATIC_I
)
TABLESPACE OWMEDIUM_D
]'  );
  end if;
  --CREATE_TIBS(TableName); --checks the CreateTable and CreateSequence inside the CREATE_TIBS
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_END2(ToReject, AppErrorText, AppErrorNumber); --Closes the current process and session if needed, will reject if ToReject was set to stnd.Yes.
END;
/