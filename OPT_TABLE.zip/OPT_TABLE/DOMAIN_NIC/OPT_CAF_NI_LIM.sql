DECLARE
  TableCount dtype.Counter%type;
  SqlStr dtype.LongStr%type;
  ProcRc dtype.Counter%type;
  ToRecreate CONSTANT dtype.Tag%type := 'N'; -- TODO Need to change before go-live!
  IsTestEnv dtype.Tag%type;
  TableName dtype.Name %type := 'OPT_CAF_NI_LIM';
  c dtype.Counter %type;
BEGIN
  ProcRc := stnd.PROCESS_START('DDL: Table: CREATE '|| TableName, null, stnd.No);

  IsTestEnv := opt_pei_forms.IS_TEST_ENV;
  select count(*) into TableCount from user_tables where table_name = TableName;

  if TableCount > 0 and ToRecreate = stnd.Yes then

    BEGIN
      SqlStr := 'drop sequence '|| TableName || '_SEQ';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'alter table '|| TableName ||' drop primary key cascade';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'drop table '|| TableName || ' cascade constraints';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END; 

  elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table '|| TableName || ' does exist and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
  -- Table
  SqlStr := '
    create table '|| TableName || ' (
        ID                NUMBER(18)  NOT NULL
      , CRDISS            VARCHAR2(32)
	  , F_I			  	  VARCHAR2(32)
	  , LIMIT_CODE	      VARCHAR2(32)
      , LIMIT_VAL         VARCHAR2(32)
      , LIMIT_TAG         VARCHAR2(32)
	  , CASH_OTB          VARCHAR2(32)
      , ADD_INFO  		  VARCHAR2(255)
    ) TABLESPACE OWMEDIUM_D
  ';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table created.');

  -- Indexes
  SqlStr := 'CREATE UNIQUE INDEX PK_'|| TableName || ' ON '|| TableName || '(ID) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  -- Sequence
  SqlStr := 'CREATE SEQUENCE '|| TableName || '_SEQ START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999999999999 MINVALUE 1 NOCYCLE CACHE 20 NOORDER';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Sequence created.');

  -- Trigger
  SqlStr := 'CREATE OR REPLACE TRIGGER '|| TableName || '_TIBS
  BEFORE INSERT ON '|| TableName || '
  for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT '|| TableName || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Trigger created.');

  <<SKIP>>
  stnd.PROCESS_END;
END;
/