DECLARE
  TableName dtype.Name%type := 'OPT_QP_PREDEF_VAL';
  TableCount dtype.Counter%type;
  IsTestEnv dtype.Tag%type;
  ToRecreate dtype.Tag%type := stnd.No;
  OnlyRecreateOnTest dtype.Tag%type := stnd.Yes;
  SqlStr VARCHAR2(32000);
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  ToStartSession dtype.Tag%type := stnd.No;
  CommitInterval dtype.Counter%type := null; --Please only use for really big changes because, when used, the rollback in case of a process reject will not be full.
  OfficerUserId dtype.Name%type := 'OWS_A';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  ToReject dtype.Tag%type; AppErrorText dtype.LongStr%type; AppErrorNumber dtype.Counter%type; --here we can put values to get the process rolled back and rejected
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    opt_ctr_util.PROCESS_MESSAGE(SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Information);
    opt_ctr_util.RELEASE_SUBPROCESS_INCREMENT;
  EXCEPTION WHEN OTHERS THEN
    opt_ctr_util.PROCESS_MESSAGE_ATX(SUBSTR(REPLACE(REPLACE('Oracle raised error:"' || SQLERRM || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Error);
    opt_ctr_util.RELEASE_SUBPROCESS_END2(stnd.Yes, SUBSTR(REPLACE(REPLACE('Failed at SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
  END;
  
  procedure CREATE_TIBS(
    TableNameIn dtype.Name%type
  )
  IS
  BEGIN
    EXEC_SQL('CREATE SEQUENCE ' || TableNameIn || '_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER');
    EXEC_SQL('CREATE OR REPLACE TRIGGER ' || TableNameIn || '_TIBS
BEFORE INSERT ON ' || TableNameIn || '
for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT ' || TableNameIn || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;
');
  END;
  
  function TO_SKIP_CREATION(
    TableNameIn dtype.Name%type
  ) RETURN dtype.Tag%type
  IS
    Result dtype.Tag%type := stnd.No;
  BEGIN
    
    IsTestEnv := opt_flex_tools.IS_TEST_ENV;
    opt_ctr_util.PROCESS_MESSAGE('Table ' || TableNameIn || ' exists'
      || '; ToRecreate=' || ToRecreate
      || '; OnlyRecreateOnTest=' || OnlyRecreateOnTest
      || ': IsTestEnv=' || IsTestEnv
      , stnd.Information
    );
    if IsTestEnv = stnd.No and OnlyRecreateOnTest = stnd.Yes then
      ToRecreate := stnd.No;
    end if;
    
    for a in(
      select *
        from user_tables
        where table_name = TableNameIn
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP TABLE ' || a.table_name || ' CASCADE CONSTRAINTS');
      else
        opt_ctr_util.PROCESS_MESSAGE('Table ' || a.table_name || ' exists and recreation is not enabled or possible', stnd.Information);
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    for a in(
      select *
        from all_sequences
        where sequence_name = TableNameIn || '_SEQ'
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP SEQUENCE ' || a.sequence_name);
      else
        opt_ctr_util.PROCESS_MESSAGE('Sequence ' || a.sequence_name || ' exists and recreation is not enabled or possible', stnd.Information);
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    RETURN Result;
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_START_P(ProcessName => FileName, ToStartSession => ToStartSession, OfficerUserId => OfficerUserId); --other parms are ProcessParms, IsUnique, ObjectType, ObjectId
  
  if TO_SKIP_CREATION(TableName) = stnd.Yes then GOTO SKIP; end if;
  
  EXEC_SQL(q'[create table OPT_QP_PREDEF_VAL (
    id                  NUMBER(18)                  CONSTRAINT PK_OPT_QP_PREDEF_VAL PRIMARY KEY USING INDEX TABLESPACE OWMEDIUM_I
  , col_code            VARCHAR2(64)    NOT NULL
  , val                 VARCHAR2(500)   NOT NULL
  , result_val          VARCHAR2(500)   
  , is_def              VARCHAR2(1)     
  , description         VARCHAR2(4000)  
  , comments            VARCHAR2(4000)  
  , add_info            VARCHAR2(4000)  
  , CONSTRAINT PK2_OPT_QP_PREDEF_VAL UNIQUE (col_code, val) USING INDEX TABLESPACE OWMEDIUM_I
)
  TABLESPACE OWMEDIUM_D]');
  CREATE_TIBS(TableName);
  
  EXEC_SQL(q'[CREATE INDEX OPT_QP_PREDEF_VAL_RES ON OPT_QP_PREDEF_VAL (col_code, val, result_val) TABLESPACE OWMEDIUM_I]');
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_END2(ToReject, AppErrorText, AppErrorNumber); --Closes the current process and session if needed, will reject if ToReject was set to stnd.Yes.
END;
/