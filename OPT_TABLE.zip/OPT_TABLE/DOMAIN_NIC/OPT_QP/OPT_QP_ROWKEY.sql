DECLARE
  TableName dtype.Name%type := 'OPT_QP_ROWKEY';
  TableCount dtype.Counter%type;
  IsTestEnv dtype.Tag%type;
  ToRecreate dtype.Tag%type := stnd.No;
  OnlyRecreateOnTest dtype.Tag%type := stnd.Yes;
  SqlStr VARCHAR2(32000);
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  ToStartSession dtype.Tag%type := stnd.No;
  CommitInterval dtype.Counter%type := null; --Please only use for really big changes because, when used, the rollback in case of a process reject will not be full.
  OfficerUserId dtype.Name%type := 'OWS_A';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  ToReject dtype.Tag%type; AppErrorText dtype.LongStr%type; AppErrorNumber dtype.Counter%type; --here we can put values to get the process rolled back and rejected
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    opt_ctr_util.PROCESS_MESSAGE(SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Information);
    opt_ctr_util.RELEASE_SUBPROCESS_INCREMENT;
  EXCEPTION WHEN OTHERS THEN
    opt_ctr_util.PROCESS_MESSAGE_ATX(SUBSTR(REPLACE(REPLACE('Oracle raised error:"' || SQLERRM || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Error);
    opt_ctr_util.RELEASE_SUBPROCESS_END2(stnd.Yes, SUBSTR(REPLACE(REPLACE('Failed at SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
  END;
  
  procedure CREATE_TIBS(
    TableNameIn dtype.Name%type
  )
  IS
  BEGIN
    EXEC_SQL('CREATE SEQUENCE ' || TableNameIn || '_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER');
    EXEC_SQL('CREATE OR REPLACE TRIGGER ' || TableNameIn || '_TIBS
BEFORE INSERT ON ' || TableNameIn || '
for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT ' || TableNameIn || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;
');
  END;
  
  function TO_SKIP_CREATION(
    TableNameIn dtype.Name%type
  ) RETURN dtype.Tag%type
  IS
    Result dtype.Tag%type := stnd.No;
  BEGIN
    
    IsTestEnv := opt_flex_tools.IS_TEST_ENV;
    opt_ctr_util.PROCESS_MESSAGE('Table ' || TableNameIn || ' exists'
      || '; ToRecreate=' || ToRecreate
      || '; OnlyRecreateOnTest=' || OnlyRecreateOnTest
      || ': IsTestEnv=' || IsTestEnv
      , stnd.Information
    );
    if IsTestEnv = stnd.No and OnlyRecreateOnTest = stnd.Yes then
      ToRecreate := stnd.No;
    end if;
    
    for a in(
      select *
        from user_tables
        where table_name = TableNameIn
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP TABLE ' || a.table_name || ' CASCADE CONSTRAINTS');
      else
        opt_ctr_util.PROCESS_MESSAGE('Table ' || a.table_name || ' exists and recreation is not enabled or possible', stnd.Information);
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    for a in(
      select *
        from all_sequences
        where sequence_name = TableNameIn || '_SEQ'
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP SEQUENCE ' || a.sequence_name);
      else
        opt_ctr_util.PROCESS_MESSAGE('Sequence ' || a.sequence_name || ' exists and recreation is not enabled or possible', stnd.Information);
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    RETURN Result;
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_START_P(ProcessName => FileName, ToStartSession => ToStartSession, OfficerUserId => OfficerUserId); --other parms are ProcessParms, IsUnique, ObjectType, ObjectId
  
  --temporary block, to be cleaned up next change
  EXEC_SQL(q'[ALTER TABLE OPT_QP_ROWKEY DROP CONSTRAINT OPT_QP_ROWKEY_ROWKEY_FI]');
  EXEC_SQL(q'[ALTER TABLE OPT_QP_ROWKEY MODIFY (
  CONSTRAINT OPT_QP_ROWKEY_ROWKEY_FI
    CHECK (NOT(length(FI_CODE) <> 3))
    ENABLE VALIDATE
  )]');
  --
  
  if TO_SKIP_CREATION(TableName) = stnd.Yes then GOTO SKIP; end if;
  
  EXEC_SQL(q'[create table OPT_QP_ROWKEY (
    id            NUMBER(18)                  CONSTRAINT PK_OPT_QP_ROWKEY PRIMARY KEY USING INDEX TABLESPACE OWMEDIUM_I
  , rowkey        VARCHAR2(32)    NOT NULL
  , fi_code       VARCHAR2(3)     NOT NULL
  , logo          VARCHAR2(3)     NOT NULL
  , pct           VARCHAR2(3)     NOT NULL
  , ccy           VARCHAR2(3)     NOT NULL
  , is_fi         VARCHAR2(1)     NOT NULL
  , is_logo       VARCHAR2(1)     NOT NULL
  , key_scope     VARCHAR2(32)    DEFAULT 'PCT' NOT NULL
  , to_exclude    VARCHAR2(1)     DEFAULT ON NULL 'N'
  , CONSTRAINT PK2_OPT_QP_ROWKEY UNIQUE (ROWKEY) USING INDEX TABLESPACE OWMEDIUM_I
)
  TABLESPACE OWMEDIUM_D]');
  CREATE_TIBS(TableName);
  
  EXEC_SQL(q'[CREATE UNIQUE INDEX OPT_QP_ROWKEY_SEP ON OPT_QP_ROWKEY (KEY_SCOPE, FI_CODE, LOGO, PCT, ROWKEY) TABLESPACE OWMEDIUM_I]');
  EXEC_SQL(q'[CREATE UNIQUE INDEX OPT_QP_ROWKEY_LOGOKEY ON OPT_QP_ROWKEY (KEY_SCOPE || '~' || FI_CODE || '~' || LOGO || '~' || CASE IS_LOGO WHEN 'Y' THEN NULL ELSE ROWKEY END ) TABLESPACE OWMEDIUM_I]');
  EXEC_SQL(q'[CREATE UNIQUE INDEX OPT_QP_ROWKEY_FIKEY ON OPT_QP_ROWKEY(KEY_SCOPE || '~' || FI_CODE || '~' || CASE IS_FI WHEN 'Y' THEN NULL ELSE ROWKEY END ) TABLESPACE OWMEDIUM_I]');
  EXEC_SQL(q'[CREATE INDEX OPT_QP_ROWKEY_SCOPE ON OPT_QP_ROWKEY (TO_EXCLUDE, KEY_SCOPE, FI_CODE, ROWKEY) TABLESPACE OWMEDIUM_I]');
  
  EXEC_SQL(q'[ALTER TABLE OPT_QP_ROWKEY ADD (
  CONSTRAINT OPT_QP_ROWKEY_LEV
    CHECK (NOT((key_scope in('FI','GLOB') and is_fi <> 'Y') or (key_scope in('LOGO') and is_logo <> 'Y')))
    ENABLE VALIDATE,
  CONSTRAINT OPT_QP_ROWKEY_ROWKEY_FI
    CHECK (NOT(length(FI_CODE) <> 3))
    ENABLE VALIDATE,
  CONSTRAINT OPT_QP_ROWKEY_ROWKEY_LOGO
    CHECK (NOT(key_scope in('FI','GLOB') and logo <> '000' or length(logo) <> 3))
    ENABLE VALIDATE,
  CONSTRAINT OPT_QP_ROWKEY_ROWKEY_PCT
    CHECK (NOT(key_scope in('FI','GLOB','LOGO') and pct <> '000' or length(pct) <> 3))
    ENABLE VALIDATE,
  CONSTRAINT OPT_QP_ROWKEY_ROWKEY_LEV
    CHECK (NOT(key_scope in('FORCE_LEVEL') and (pct <> 'lev' or logo <> '000')))
    ENABLE VALIDATE,
  CONSTRAINT OPT_QP_ROWKEY_ROWKEY_RULE
    CHECK (  fi_code 
          ||  case when key_scope in('LOGO','PCT','FORCE_LEVEL') then '-' || logo end 
          ||  case when key_scope in('PCT','FORCE_LEVEL') then '-' || pct
          end = rowkey
         )
    ENABLE VALIDATE,
  CONSTRAINT OPT_QP_ROWKEY_IS_FI
    CHECK (is_fi in('Y','N'))
    ENABLE VALIDATE,
  CONSTRAINT OPT_QP_ROWKEY_IS_LOGO
    CHECK (is_logo in('Y','N'))
    ENABLE VALIDATE,
  CONSTRAINT OPT_QP_ROWKEY_TO_EXCLUDE
    CHECK (TO_EXCLUDE in('Y','N'))
    ENABLE VALIDATE
  )]');
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_END2(ToReject, AppErrorText, AppErrorNumber); --Closes the current process and session if needed, will reject if ToReject was set to stnd.Yes.
END;
/