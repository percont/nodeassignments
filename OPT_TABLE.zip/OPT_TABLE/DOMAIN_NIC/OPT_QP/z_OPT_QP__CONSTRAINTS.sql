DECLARE
  TableName dtype.Name%type := 'z_OPT_QP__CONSTRAINTS';
  TableCount dtype.Counter%type;
  IsTestEnv dtype.Tag%type;
  ToRecreate dtype.Tag%type := stnd.No;
  OnlyRecreateOnTest dtype.Tag%type := stnd.Yes;
  SqlStr VARCHAR2(32000);
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  ToStartSession dtype.Tag%type := stnd.No;
  CommitInterval dtype.Counter%type := null; --Please only use for really big changes because, when used, the rollback in case of a process reject will not be full.
  OfficerUserId dtype.Name%type := 'OWS_A';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  ToReject dtype.Tag%type; AppErrorText dtype.LongStr%type; AppErrorNumber dtype.Counter%type; --here we can put values to get the process rolled back and rejected
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    opt_ctr_util.PROCESS_MESSAGE(SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Information);
    opt_ctr_util.RELEASE_SUBPROCESS_INCREMENT;
  EXCEPTION WHEN OTHERS THEN
    opt_ctr_util.PROCESS_MESSAGE_ATX(SUBSTR(REPLACE(REPLACE('Oracle raised error:"' || SQLERRM || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Error);
    opt_ctr_util.RELEASE_SUBPROCESS_END2(stnd.Yes, SUBSTR(REPLACE(REPLACE('Failed at SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
  END;
  
  procedure RECREATE_CONSTRAINT(
    TableNameIn dtype.Name%type,
    ConstraintNameIn dtype.Name%type,
    ConstraintBodyIn dtype.Name%type,
    DropOnly dtype.Tag%type DEFAULT stnd.No
  )
  IS
  BEGIN
    for a in(
      select *
        from user_constraints
        where table_name = TableNameIn
          and constraint_name = ConstraintNameIn
    ) LOOP
      EXEC_SQL('ALTER TABLE ' || TableNameIn || ' DROP CONSTRAINT ' || ConstraintNameIn);
      EXIT;
    END LOOP;
    if DropOnly = stnd.Yes then
      NULL;
    else
      EXEC_SQL('ALTER TABLE ' || TableNameIn || ' ADD CONSTRAINT ' || ConstraintNameIn || ' ' || ConstraintBodyIn);
    end if;
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_START_P(ProcessName => FileName, ToStartSession => ToStartSession, OfficerUserId => OfficerUserId); --other parms are ProcessParms, IsUnique, ObjectType, ObjectId
  
  RECREATE_CONSTRAINT('OPT_QP_COLUMN'     , 'OPT_QP_COLUMN_FK_DOMAIN'       , q'[FOREIGN KEY (domain)               REFERENCES OPT_QP_DOMAIN    (domain)                                          ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_COLUMN'     , 'OPT_QP_COLUMN_FK_PARM_TYPE'    , q'[FOREIGN KEY (parm_type)            REFERENCES OPT_QP_PARM_TYPE (parm_type)                                       ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_COLUMN'     , 'OPT_QP_COLUMN_FK_QUEST'        , q'[FOREIGN KEY (quest)                REFERENCES OPT_QP_QUEST     (code)                                            ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_COLUMN'     , 'OPT_QP_COLUMN_FK_QUEST_DOMAIN' , q'[FOREIGN KEY (domain, quest)        REFERENCES OPT_QP_QUEST     (domain, code)      initially deferred deferrable ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_COLUMN'     , 'OPT_QP_COLUMN_FK_SRC'          , q'[FOREIGN KEY (col_code_src)         REFERENCES OPT_QP_COLUMN    (col_code)                                        ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_COLUMN'     , 'OPT_QP_COLUMN_FK_SRC_DOMAIN'   , q'[FOREIGN KEY (domain, col_code_src) REFERENCES OPT_QP_COLUMN    (domain, col_code)                                ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_FI'         , 'OPT_QP_FI_FK_DOMAIN'           , q'[FOREIGN KEY (domain)               REFERENCES OPT_QP_DOMAIN    (domain)                                          ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_FI_PARM'    , 'OPT_QP_FI_PARM_FK_FI'          , q'[FOREIGN KEY (fi_code)              REFERENCES OPT_QP_FI        (fi_code)                                         ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_FI_PARM'    , 'OPT_QP_FI_PARM_FK_PARM_TYPE'   , q'[FOREIGN KEY (parm_type)            REFERENCES OPT_QP_PARM_TYPE (parm_type)                                       ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_INPUT'      , 'OPT_QP_INPUT_FK_COL'           , q'[FOREIGN KEY (col_code)             REFERENCES OPT_QP_COLUMN    (col_code)                                        ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_INPUT'      , 'OPT_QP_INPUT_FK_PARM'          , q'[FOREIGN KEY (parm_code)            REFERENCES OPT_QP_FI_PARM   (parm_code)                                       ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_INPUT'      , 'OPT_QP_INPUT_FK_RK'            , q'[FOREIGN KEY (rowkey)               REFERENCES OPT_QP_ROWKEY    (rowkey)                                          ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_INPUT_ADD'  , 'OPT_QP_INPUT_ADD_FK_COL'       , q'[FOREIGN KEY (col_code)             REFERENCES OPT_QP_COLUMN    (col_code)          ON DELETE CASCADE             ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_INPUT_ADD'  , 'OPT_QP_INPUT_ADD_FK_RK'        , q'[FOREIGN KEY (rowkey)               REFERENCES OPT_QP_ROWKEY    (rowkey)            ON DELETE CASCADE             ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_OO_TARIFF'  , 'OPT_QP_OO_TARIFF_FK_DOMAIN'    , q'[FOREIGN KEY (domain)               REFERENCES OPT_QP_DOMAIN    (domain)                                          ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_PARM_TYPE'  , 'OPT_QP_PARM_TYPE_FK_DOMAIN'    , q'[FOREIGN KEY (domain)               REFERENCES OPT_QP_DOMAIN    (domain)                                          ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_PREDEF_VAL' , 'OPT_QP_PREDEF_VAL_FK_COL'      , q'[FOREIGN KEY (col_code)             REFERENCES OPT_QP_COLUMN    (col_code)                                        ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_QUEST'      , 'OPT_QP_QUEST_FK_DOMAIN'        , q'[FOREIGN KEY (domain)               REFERENCES OPT_QP_DOMAIN    (domain)                                          ]', stnd.No);
  RECREATE_CONSTRAINT('OPT_QP_ROWKEY'     , 'OPT_QP_ROWKEY_FK_FI'           , q'[FOREIGN KEY (fi_code)              REFERENCES OPT_QP_FI        (fi_code)                                         ]', stnd.No);
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_END2(ToReject, AppErrorText, AppErrorNumber); --Closes the current process and session if needed, will reject if ToReject was set to stnd.Yes.
END;
/
