declare
    TABLE_C   number;
begin
    begin
        execute immediate 'DROP TABLE OPT_WAY4_BILLING_INFO';
    exception
        when others then
            null;
    end;
    select
        count(*)
    into TABLE_C
    from
        USER_OBJECTS
    where
        OBJECT_TYPE = 'TABLE'
        and OBJECT_NAME = 'OPT_WAY4_BILLING_INFO';

    if ( TABLE_C = 0 ) then
        execute immediate '
    create table opt_way4_billing_info (
										src_sys varchar2(10 byte),
										bill_on varchar2(10 byte), 	
										banking_date date, 
										org char(3 byte), 
										bank_name varchar2(255 byte), 
										con_n_card_idt number(18), 
										con_n_card varchar2(255 byte), 
										client_short_name varchar2(255 byte), 
										status_name varchar2(255 byte), 
										status_code varchar2(1 byte), 
										acc_block_code_1 varchar2(5 byte), 
										acc_block_code_2 varchar2(5 byte), 
										card_block_code  varchar2(5 byte), 
										expiry_date date, 
										card_product_id number(18)
										) 
										/*   
										partition by list (org)
										( partition org_020 values (''020''),
										  partition org_030 values (''030''),
										  partition status_null values (null),
										  partition status_unknown values (default)
										)
										*/
									tablespace owstatic_d'
        ;
    end if;
    select
        count(*)
    into TABLE_C
    from
        USER_OBJECTS
    where
        OBJECT_TYPE = 'INDEX'
        and OBJECT_NAME = 'OPT_WAY4_BILLING_INFO_ORG';

    if ( TABLE_C = 0 ) then
        execute immediate 'create index OPT_WAY4_BILLING_INFO_ORG on OPT_WAY4_BILLING_INFO(ORG)';
    end if;
end;
/