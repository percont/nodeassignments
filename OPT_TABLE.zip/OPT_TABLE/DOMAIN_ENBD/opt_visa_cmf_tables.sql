/*
  This script creates tables provided in OWI_UAENETWKI-VIS-20161026_1
*/
declare
c dtype.Counter %type;
sqlStr dtype.LongStr %type;
rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE:opt_visa_cmf_table - Create OPT_VISA_CMF_COLLECTION', null, stnd.No);
  select min(1) into c from user_tables where table_name = 'OPT_VISA_CMF_COLLECTION';
  if c is null then
    -- Table
    sqlStr := 'create table OPT_VISA_CMF_COLLECTION(
    id number(18, 0) not null
    ,is_base varchar2(1) default ''N'' not null 
    ,export_date date default sysdate not null 
    ,export_type varchar2(1)
    ,export_state varchar2(1)
    ,constraint PK_OPT_VISA_CMF_COLLECTION primary key (id) 
    )';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Table created.');
    -- Index
    sqlStr := 'create unique index IDX_OPT_VISA_CMF_COLLECTION on OPT_VISA_CMF_COLLECTION(is_base, export_date)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created.');
    -- Sequence
    sqlStr := 'create sequence opt_visa_cmf_collection_seq minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 1 cache 20 noorder nocycle';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Sequence created.');
    -- Trigger
    sqlStr := 'create trigger trg_opt_visa_cmf_collection
              before insert on OPT_VISA_CMF_COLLECTION
              for each row
              begin
              if :new.id is null then
               :new.id := opt_visa_cmf_collection_seq.nextval;
              end if;
              end;';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Trigger created.');
  else
    stnd.process_message(stnd.Information, 'Table already exists. Skipped!');
  end if;
  stnd.process_end;
end;
/
-- opt_visa_cmf_sender_seq
declare
c dtype.Counter %type;
sqlStr dtype.LongStr %type;
rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE:opt_visa_cmf_table - Create OPT_VISA_CMF_SENDER_SEQ', null, stnd.No);
  select min(1) into c from user_tables where table_name = 'OPT_VISA_CMF_SENDER_SEQ';
  if c is null then
    -- Table
    sqlStr := 'create table OPT_VISA_CMF_SENDER_SEQ(
    id number(18, 0) not null
    ,collection__oid number(18, 0) not null
    ,sender_id number not null
    ,sender_seq_num number not null
    ,is_main varchar2(1) not null
    ,constraint PK_OPT_VISA_CMF_SENDER_SEQ primary key (id)
    ,constraint FK_OPT_VISA_CMF_COLLECTION_2 foreign key (collection__oid) references OPT_VISA_CMF_COLLECTION (id)
    )';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Table created.');
    -- Index 1
    sqlStr := 'create unique index IDX_OPT_VISA_CMF_SENDER_SEQ on OPT_VISA_CMF_SENDER_SEQ(sender_id, sender_seq_num)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created.');
    -- Index 2
    sqlStr := 'create index IDX_OPT_VISA_CMF_SENDER_SEQ_2 on OPT_VISA_CMF_SENDER_SEQ(collection__oid)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created.');
    
    -- Sequence
    sqlStr := 'create sequence opt_visa_cmf_sender_seq_seq minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 1 cache 20 noorder nocycle';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Sequence created.');
    -- Trigger
    sqlStr := 'create trigger trg_opt_visa_cmf_sender_seq
    before insert on OPT_VISA_CMF_SENDER_SEQ
    for each row
    begin
     if :new.id is null then
      :new.id := opt_visa_cmf_sender_seq_seq.nextval;
     end if;
    end;';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Trigger created.');
  else
    stnd.process_message(stnd.Information, 'Table already exists. Skipped!');
  end if;
  stnd.process_end;
end;
/
-- opt_visa_cmf_group
declare
c dtype.Counter %type;
sqlStr dtype.LongStr %type;
rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE:opt_visa_cmf_table - Create OPT_VISA_CMF_SENDER_SEQ', null, stnd.No);
  select min(1) into c from user_tables where table_name = 'OPT_VISA_CMF_GROUP';
  if c is null then
    -- Table
    sqlStr := 'create table OPT_VISA_CMF_GROUP(
    id number(18, 0) not null
    ,collection__oid number(18, 0) not null
    ,client__id number(18, 0) not null
    ,group_number varchar2(32)
    ,last_export_date date
    ,constraint PK_OPT_VISA_CMF_GROUP primary key (id)
    ,constraint FK_OPT_VISA_CMF_COLLECTION foreign key (collection__oid) references OPT_VISA_CMF_COLLECTION (id)
    )';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Table created.');
    -- Index 1
    sqlStr := 'create unique index IDX_OPT_VISA_CMF_GROUP on OPT_VISA_CMF_GROUP(collection__oid, client__id)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created.');
    -- Sequence
    sqlStr := 'create sequence opt_visa_cmf_group_seq minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 1 cache 20 noorder nocycle';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Sequence created.');
    -- Trigger
    sqlStr := 'create trigger trg_opt_visa_cmf_group
    before insert on OPT_VISA_CMF_GROUP
    for each row
    begin
      if :new.id is null then
        :new.id := opt_visa_cmf_group_seq.nextval;
      end if;
    end;';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Trigger created.');
  else
    stnd.process_message(stnd.Information, 'Table already exists. Skipped!');
  end if;
  stnd.process_end;
end;
/
-- opt_visa_cmf_card
declare
c dtype.Counter %type;
sqlStr dtype.LongStr %type;
rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE:opt_visa_cmf_table - Create OPT_VISA_CMF_SENDER_SEQ', null, stnd.No);
  select min(1) into c from user_tables where table_name = 'OPT_VISA_CMF_CARD';
  if c is null then
    -- Table
    sqlStr := 'create table OPT_VISA_CMF_CARD(
    id number(18, 0) not null
    ,group__oid number(18, 0) not null
    ,contract__id number(18, 0) not null
    ,card_type varchar2(1) not null
    ,card_number varchar2(32) not null
    ,expiry_date varchar2(4) not null
    ,constraint PK_OPT_VISA_CMF_CARD primary key (id)
    ,constraint FK_OPT_VISA_CMF_GROUP foreign key (group__oid) references OPT_VISA_CMF_GROUP (id)
    )';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Table created.');
    -- Index 1
    sqlStr := 'create unique index IDX_OPT_VISA_CMF_CARD on OPT_VISA_CMF_CARD(group__oid, contract__id)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created.');
    -- Sequence
    sqlStr := 'create sequence opt_visa_cmf_card_seq minvalue 1 maxvalue 9999999999999999999999999999 increment by 1 start with 1 cache 20 noorder nocycle';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Sequence created.');
    -- Trigger
    sqlStr := 'create trigger trg_opt_visa_cmf_card
    before insert on OPT_VISA_CMF_CARD
    for each row
    begin
      if :new.id is null then
        :new.id := opt_visa_cmf_card_seq.nextval;
      end if;
    end;';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Trigger created.');
  else
    stnd.process_message(stnd.Information, 'Table already exists. Skipped!');
  end if;
  stnd.process_end;
end;
/