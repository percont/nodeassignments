-- create table used for recon reports creation during ENBD migration
declare
c dtype.Counter %type;
sqlStr dtype.LongStr %type;
rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE: create OPT_ENBD_D0_CONTRACT table', null, stnd.No);
  select min(1) into c from user_tables where table_name = 'OPT_ENBD_D0_CONTRACT';
  if c is null then
     sqlStr := 'CREATE TABLE OPT_ENBD_D0_CONTRACT
( BANK_CODE          VARCHAR2(32 CHAR),
  CON_CAT            VARCHAR2(1),
  CONTRACT_NUMBER    VARCHAR2(64) ) ';
     execute immediate sqlStr;          
     sqlStr := 'create unique index OPT_ENBD_D0_CONTRACT_UK on OWS.OPT_ENBD_D0_CONTRACT (BANK_CODE,CONTRACT_NUMBER)';
     execute immediate sqlStr;          
     stnd.process_message(stnd.Information, 'Table OPT_ENBD_D0_CONTRACT is created.');
  end if;   
  stnd.process_end;
end;
/
