DECLARE
  TableCount dtype.Counter%type;
  SqlStr dtype.LongStr%type;
  ProcRc dtype.Counter%type;
  ToRecreate CONSTANT dtype.Tag%type := 'N'; -- TODO Need to change before go-live!
  IsTestEnv dtype.Tag%type;
  TableName dtype.Name %type := 'OPT_EGCC_LTY_PRGM';
  c dtype.Counter %type;
BEGIN
  ProcRc := stnd.PROCESS_START('DDL: Table: CREATE '|| TableName, null, stnd.No);

  IsTestEnv := opt_pei_forms.IS_TEST_ENV;
  select count(*) into TableCount from user_tables where table_name = TableName;

  if TableCount > 0 and ToRecreate = stnd.Yes then

    BEGIN
      SqlStr := 'drop sequence '|| TableName || '_SEQ';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'alter table '|| TableName ||' drop primary key cascade';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'drop table '|| TableName || ' cascade constraints';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END; 

  elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table '|| TableName || ' does exist and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
  -- Table
  SqlStr := '
    create table '|| TableName || ' (
        ID                 NUMBER(18)  NOT NULL
      , FI_CODE            VARCHAR2(3) NOT NULL
      , LOGO               VARCHAR2(255)
      , PCT                VARCHAR2(255)
      , TRANS_TYPE         VARCHAR2(255)
      , INCLUDED_SIC_LIST  VARCHAR2(3900)
      , EXCLUDED_SIC_LIST  VARCHAR2(3900)
      , INCLUDED_MID_LIST	 VARCHAR2(3900)
      , EXCLUDED_MID_LIST	 VARCHAR2(3900)
      , INCLUDED_COUNTRY_LIST VARCHAR2(3900)
      , EXCLUDED_COUNTRY_LIST VARCHAR2(3900)
      , INCOMING_CHANNEL   VARCHAR2(32)
      , AREA				       VARCHAR2(32)
      , DAY_OF_WEEK			   VARCHAR2(32)
      , DAY_OF_MONTH		   VARCHAR2(100)
      , GROUP_NUMBER       NUMBER(2)
      , DATE_FROM          DATE
      , DATE_TO            DATE      
      , APPLY_RULES			   VARCHAR2(3900)
      , IS_ACTIVE          VARCHAR2(1)
      , WEIGHT				     NUMBER(6)
      , PRIORITY			     NUMBER(3)
    ) TABLESPACE OWMEDIUM_D
  ';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table created.');

  -- Indexes
  SqlStr := 'CREATE UNIQUE INDEX PK_'|| TableName || ' ON '|| TableName || '(ID) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  SqlStr := 'CREATE INDEX '|| TableName || '_BASE ON '|| TableName || '(IS_ACTIVE, FI_CODE, LOGO, PCT, TRANS_TYPE, DATE_FROM, DATE_TO) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  -- Sequence
  SqlStr := 'CREATE SEQUENCE '|| TableName || '_SEQ START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999999999999 MINVALUE 1 NOCYCLE CACHE 20 NOORDER';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Sequence created.');

  -- Trigger
  SqlStr := 'CREATE OR REPLACE TRIGGER '|| TableName || '_TIBS
  BEFORE INSERT ON '|| TableName || '
  for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT '|| TableName || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Trigger created.');

  <<SKIP>>
    select count(*) into c from ALL_TAB_COLUMNS where column_name = 'INCLUDED_COUNTRY_LIST' and table_name = TableName;
   if c = 0 then
    SqlStr := 'ALTER TABLE '|| TableName || ' ADD INCLUDED_COUNTRY_LIST VARCHAR2(3900)';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
   end if;
    select count(*) into c from ALL_TAB_COLUMNS where column_name = 'EXCLUDED_COUNTRY_LIST' and table_name = TableName;
   if c = 0 then
    SqlStr := 'ALTER TABLE '|| TableName || ' ADD EXCLUDED_COUNTRY_LIST VARCHAR2(3900)';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Adding Table column. SQL:"' || SqlStr || '"');
   end if;

  stnd.PROCESS_END;
END;
/