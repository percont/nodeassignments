-- OPT_ENBDGR_ISG_REJECT_ENTRY
-- Usage: OPT_ENBDGR_ISG_REJECT_ENTRY report
-- 20180426.001 Initial version. Copied from ENBD_CC(ver.002)
DECLARE
  v_table_name user_tables.table_name%TYPE:= 'OPT_ENBDGR_ISG_REJECT_ENTRY';
BEGIN

  begin
    for rec in (select 1 from user_tables where table_name = v_table_name and temporary = 'N' having count(1) = 1) loop
	   execute immediate 'DROP TABLE '|| v_table_name;
	end loop;
  end;
  
  for rec in (select 1 from user_tables where table_name = v_table_name having count(1) = 0)
  loop
      execute immediate '
            CREATE GLOBAL TEMPORARY TABLE '||v_table_name||'
             	(
    CONTRACT_IDT     NUMBER(18,0),
    PRIMARY_DOC_IDT  NUMBER(18,0),
    AMND_PREV        NUMBER(18,0),
    ORG              VARCHAR2(32 CHAR),
    LOGO             VARCHAR2(3 CHAR),
    CARD_NBR         VARCHAR2(76 BYTE),
    ACCT             VARCHAR2(76 BYTE),
    POSTING_DATE     VARCHAR2(8 BYTE),
    EFF_DATE         VARCHAR2(8 BYTE),
    DIRECTION        VARCHAR2(1 BYTE),
    TXN_CODE         CHAR(3 BYTE),
    LOGIC_MODULE     CHAR(2 BYTE),
    DESCRIPTION      VARCHAR2(10 BYTE),
    TRANS_AMOUNT     VARCHAR2(44 BYTE),
    REF_NUMBER       VARCHAR2(92 BYTE),
    GL_SOURCE        CHAR(1 BYTE),
    MT_SOURCE        CHAR(5 BYTE),
    PLAN             CHAR(5 BYTE),
    PLAN_SEQ         CHAR(2 BYTE),
    POSTING_FLAG     CHAR(2 BYTE)
    )  
   ON COMMIT PRESERVE ROWS';
  end loop;

  END;
/		