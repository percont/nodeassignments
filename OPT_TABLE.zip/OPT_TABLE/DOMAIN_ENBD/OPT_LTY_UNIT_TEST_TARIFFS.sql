DECLARE
  TableCount dtype.Counter%type;
  SqlStr dtype.LongStr%type;
  ProcRc dtype.Counter%type;
  ToRecreate CONSTANT dtype.Tag%type := 'Y'; -- TODO Need to change before go-live!
  IsTestEnv dtype.Tag%type;
  TableName dtype.Name %type := 'OPT_LTY_UNIT_TEST_TARIFFS';
  c dtype.Counter %type;
BEGIN
  ProcRc := stnd.PROCESS_START('DDL: Table: CREATE '|| TableName, null, stnd.No);

  IsTestEnv := opt_pei_forms.IS_TEST_ENV;
  select count(*) into TableCount from user_tables where table_name = TableName;

  if TableCount > 0 and ToRecreate = stnd.Yes then

    BEGIN
      SqlStr := 'drop table '|| TableName || ' cascade constraints';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END; 

  elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table '|| TableName || ' does exist and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
  -- Table
  SqlStr := '
    create table '|| TableName || ' (
        PGM_ROWKEY              VARCHAR2(1032 CHAR),
  GRP_ROWKEY              VARCHAR2(1043 CHAR),
  LVL                     VARCHAR2(9 CHAR),
  BANK_CODE               VARCHAR2(3 CHAR),
  LOGO                    VARCHAR2(3 CHAR),
  PCT                     VARCHAR2(3 CHAR),
  LTY_PROGRAM             VARCHAR2(1020 CHAR),
  LTY_GROUP               VARCHAR2(6 CHAR),
  GROUP_NAME              VARCHAR2(255 CHAR),
  TARIFF_ROLE             VARCHAR2(32 CHAR),
  TARIFF_TYPE             VARCHAR2(32 CHAR),
  TARIFF_NAME             VARCHAR2(255 CHAR),
  TABLE_CODE_FROM         VARCHAR2(255 CHAR),
  ACCRUAL_PERCENTAGE      VARCHAR2(40 CHAR),
  ACCRUAL_MAX_AMOUNT      VARCHAR2(40 CHAR),
  FIRST_USAGE_BONUS       VARCHAR2(40 CHAR),
  CREDIT_LIMIT_CAP        CHAR(1 CHAR),
  CREDIT_LIMIT_GROUP_CAP  CHAR(1 CHAR),
  LTY_AMF_FIRST_YEAR      NUMBER,
  LTY_AMF_OTHER_YEAR      NUMBER,
  YEARLY_PROGRAM_CAP      NUMBER,
  EXPIRY_WARNING_PERIOD   VARCHAR2(40 CHAR),
  EXPIRY_PERIOD           VARCHAR2(40 CHAR),
  SLICE_THRESHOLD         VARCHAR2(40 CHAR),
  SLICE_ACCRUAL_RATE      VARCHAR2(40 CHAR),
  SLAB_MIN_BALANCE        VARCHAR2(4000 CHAR),
  SLAB_MAX_BALANCE        VARCHAR2(4000 CHAR),
  TARIFF_DATE_FROM        DATE,
  TARIFF_IS_ACTIVE        VARCHAR2(1 CHAR)
    ) TABLESPACE OWMEDIUM_D
  ';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table created.');

  <<SKIP>>
  stnd.PROCESS_END;
END;
/