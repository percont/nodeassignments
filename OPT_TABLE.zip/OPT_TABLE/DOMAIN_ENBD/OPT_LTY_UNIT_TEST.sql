DECLARE
  TableCount dtype.Counter%type;
  SqlStr dtype.LongStr%type;
  ProcRc dtype.Counter%type;
  ToRecreate CONSTANT dtype.Tag%type := 'Y'; -- TODO Need to change before go-live!
  IsTestEnv dtype.Tag%type;
  TableName dtype.Name %type := 'OPT_LTY_UNIT_TEST';
  c dtype.Counter %type;
BEGIN
  ProcRc := stnd.PROCESS_START('DDL: Table: CREATE '|| TableName, null, stnd.No);

  IsTestEnv := opt_pei_forms.IS_TEST_ENV;
  select count(*) into TableCount from user_tables where table_name = TableName;

  if TableCount > 0 and ToRecreate = stnd.Yes then

    BEGIN
      SqlStr := 'drop sequence '|| TableName || '_SEQ';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'alter table '|| TableName ||' drop primary key cascade';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'drop table '|| TableName || ' cascade constraints';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END; 

  elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table '|| TableName || ' does exist and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
  -- Table
  SqlStr := '
    create table '|| TableName || ' (
        ID                 NUMBER(18)  NOT NULL
      , FI_CODE            VARCHAR2(3) NOT NULL
      , LOGO               VARCHAR2(255)
      , TRANS_TYPE         VARCHAR2(255)
      , MCC  VARCHAR2(10)
      , MID  VARCHAR2(32)
      , MERCHANT_COUNTRY   VARCHAR2(3)
      , TRANS_DATE VARCHAR2(10)
      , TRANS_AMOUNT   NUMBER(28,10)
      , TRANS_CURRENCY VARCHAR2(3)
      , ASSERT_RATE    NUMBER(15,8)
      , ASSERT_POINTS  NUMBER(28,10)
      , ASSERT_PROGRAM_NUMBER       NUMBER(3)
      , ASSERT_GROUP_NUMBER       NUMBER(3)
      , ACTUAL_RATE    NUMBER(15,8)
      , ACTUAL_POINTS  NUMBER(28,10)
      , ACTUAL_PROGRAM_NUMBER       NUMBER(3)
      , ACTUAL_GROUP_NUMBER       NUMBER(3)
      , ACTUAL_MODE VARCHAR2(1)
      , RESULT         VARCHAR2(1)
    ) TABLESPACE OWMEDIUM_D
  ';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Table created.');

  -- Indexes
  SqlStr := 'CREATE UNIQUE INDEX PK_'|| TableName || ' ON '|| TableName || '(ID) TABLESPACE OWMEDIUM_I';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Index created at SQL:"' || SqlStr || '"');

  -- Sequence
  SqlStr := 'CREATE SEQUENCE '|| TableName || '_SEQ START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999999999999 MINVALUE 1 NOCYCLE CACHE 20 NOORDER';
  EXECUTE IMMEDIATE SqlStr;
  stnd.PROCESS_MESSAGE(stnd.Information, 'Sequence created.');

  -- Trigger
  SqlStr := 'CREATE OR REPLACE TRIGGER '|| TableName || '_TIBS
  BEFORE INSERT ON '|| TableName || '
  for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT '|| TableName || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;';
    EXECUTE IMMEDIATE SqlStr;
    stnd.PROCESS_MESSAGE(stnd.Information, 'Trigger created.');

  <<SKIP>>
  stnd.PROCESS_END;
END;
/