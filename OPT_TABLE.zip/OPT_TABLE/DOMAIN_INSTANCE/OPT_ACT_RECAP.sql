-- OPT_ACT_RECAP - used in NI.BBY.Activity Recap report
-- 20211212.001 table created 


DECLARE
  v_table_name user_tables.table_name%TYPE:= 'OPT_ACT_RECAP';
BEGIN
  begin
	execute immediate 'DROP TABLE '|| v_table_name;
	exception when others then null;
  end;
  for rec in (select 1 from user_tables where table_name = v_table_name having count(1) = 0)
  loop
      execute immediate '
            CREATE TABLE '||v_table_name||'
(
  ORG       NUMBER(18)                          NOT NULL,
  LOGO      VARCHAR2(32)                        NOT NULL,
  TXN_CODE  VARCHAR2(32)                        NOT NULL,
  NAME      VARCHAR2(255),
  REP_DATE  DATE,
  REP_NUM   NUMBER(18),
  REP_AMNT  NUMBER
)
TABLESPACE OWLARGE_D
PCTUSED    0
PCTFREE    10
INITRANS   1
MAXTRANS   255
STORAGE    (
            INITIAL          64K
            NEXT             64K
            MINEXTENTS       1
            MAXEXTENTS       UNLIMITED
            PCTINCREASE      0
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCOMPRESS 
NOCACHE
MONITORING';

      execute immediate 'CREATE UNIQUE INDEX '||v_table_name||'_DATE ON OPT_ACT_RECAP (ORG, LOGO, TXN_CODE, REP_DATE) TABLESPACE OWLARGE_I';

  end loop;
 END;
/	