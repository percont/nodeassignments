DECLARE
  TableName dtype.Name%type := 'OPT_NI_STG_REPORT_MONETARY';
  TableCount dtype.Counter%type;
  IsTestEnv dtype.Tag%type;
  ToRecreate dtype.Tag%type := stnd.No;
  OnlyRecreateOnTest dtype.Tag%type := stnd.Yes;
  SqlStr VARCHAR2(32000);
  
  FileName CONSTANT dtype.Name%type := TableName || '.sql';
  ToStartSession dtype.Tag%type := stnd.No;
  CommitInterval dtype.Counter%type := null; --Please only use for really big changes because, when used, the rollback in case of a process reject will not be full.
  OfficerUserId dtype.Name%type := 'OWS_A';
  
  ErrMsg dtype.ErrorMessage%type; --this can be used when calling functions that return dtype.ErrorMessage%type
  ToReject dtype.Tag%type; AppErrorText dtype.LongStr%type; AppErrorNumber dtype.Counter%type; --here we can put values to get the process rolled back and rejected
  
  procedure EXEC_SQL(
    SqlStrIn VARCHAR2
  )
  IS
  BEGIN
    EXECUTE IMMEDIATE SqlStrIn;
    opt_calc.PROCESS_MESSAGE(SUBSTR(REPLACE(REPLACE('Executed SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Information);
    opt_ctr_util.RELEASE_SUBPROCESS_INCREMENT;
  EXCEPTION WHEN OTHERS THEN
    opt_ctr_util.PROCESS_MESSAGE_ATX(SUBSTR(REPLACE(REPLACE('Oracle raised error:"' || SQLERRM || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900), stnd.Error);
    opt_ctr_util.RELEASE_SUBPROCESS_END2(stnd.Yes, SUBSTR(REPLACE(REPLACE('Failed at SQL:"' || SqlStrIn || '"', CHR(10), ' '), CHR(13), ' '), 1, 3900));
  END;
  
  procedure CREATE_TIBS(
    TableNameIn dtype.Name%type
  )
  IS
  BEGIN
    select count(*)
      into TableCount
      from all_sequences
      where sequence_name = TableNameIn || '_SEQ'
    ;
    if TableCount = 0 then
      EXEC_SQL('CREATE SEQUENCE ' || TableNameIn || '_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER');
    end if;
    EXEC_SQL('CREATE OR REPLACE TRIGGER ' || TableNameIn || '_TIBS
BEFORE INSERT ON ' || TableNameIn || '
for each row
BEGIN
  IF :new.ID IS NULL THEN
    SELECT ' || TableNameIn || '_SEQ.NEXTVAL INTO :new.ID FROM DUAL;
  END IF;
END;
');
  END;
  
  function TO_SKIP_CREATION(
    TableNameIn dtype.Name%type
  ) RETURN dtype.Tag%type
  IS
    Result dtype.Tag%type := stnd.No;
  BEGIN
    
    IsTestEnv := opt_pei_forms.IS_TEST_ENV;
    opt_calc.PROCESS_MESSAGE('Table ' || TableNameIn || ' exists'
      || '; ToRecreate=' || ToRecreate
      || '; OnlyRecreateOnTest=' || OnlyRecreateOnTest
      || ': IsTestEnv=' || IsTestEnv
      , stnd.Information
    );
    if IsTestEnv = stnd.No and OnlyRecreateOnTest = stnd.Yes then
      ToRecreate := stnd.No;
    end if;
    
    for a in(
      select *
        from user_tables
        where table_name = TableNameIn
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP TABLE ' || a.table_name || ' CASCADE CONSTRAINTS');
      else
        opt_calc.PROCESS_MESSAGE('Table ' || a.table_name || ' exists and recreation is not enabled or possible', stnd.Information);
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    for a in(
      select *
        from all_sequences
        where sequence_name = TableNameIn || '_SEQ'
    ) LOOP
      if ToRecreate = stnd.Yes then
        EXEC_SQL('DROP SEQUENCE ' || a.sequence_name);
      else
        opt_calc.PROCESS_MESSAGE('Sequence ' || a.sequence_name || ' exists and recreation is not enabled or possible', stnd.Information);
        Result := stnd.Yes;
      end if;
      EXIT;
    END LOOP;
    
    RETURN Result;
  END;
  
  procedure SYNCH_SEQ(
    TableNameIn dtype.Name%type
  )
  IS
    SeqName dtype.Name%type;
    MaxVal dtype.Counter%type;
    SeqVal dtype.Counter%type;
  BEGIN
    
    SeqName := TableNameIn || '_SEQ';
    EXECUTE IMMEDIATE 'select max(id) from ' || TableNameIn into MaxVal;
    EXECUTE IMMEDIATE 'select '|| SeqName || '.nextval from dual' into SeqVal;
    
    if MaxVal > SeqVal then
      EXEC_SQL('alter sequence ' || SeqName || ' increment by ' ||  ( MaxVal - SeqVal ));
      EXECUTE IMMEDIATE 'select ' || SeqName || '.nextval from dual' into SeqVal;
      EXEC_SQL('alter sequence ' || SeqName || ' increment by 1');
      EXECUTE IMMEDIATE 'select ' || SeqName || '.nextval from dual' into SeqVal;
    end if;
    
  END;
  
BEGIN
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_START_P(ProcessName => FileName, ToStartSession => ToStartSession, OfficerUserId => OfficerUserId); --other parms are ProcessParms, IsUnique, ObjectType, ObjectId
      
  if TO_SKIP_CREATION(TableName) = stnd.Yes then GOTO SKIP; end if;
  
  EXEC_SQL(q'[CREATE TABLE OPT_NI_STG_REPORT_MONETARY
(
  REPORTING_DATE    DATE,
  DIRECTION         VARCHAR2(32 CHAR),
  PAY_SYSTEM        VARCHAR2(32 CHAR),
  FILE_TYPE         VARCHAR2(32 CHAR),
  CHANNEL_CODE      VARCHAR2(32 CHAR),
  F_I               NUMBER(18),
  BANK_CODE         VARCHAR2(32 CHAR),
  MEMBER_ID         VARCHAR2(32 CHAR),
  TRANS_TYPE_NAME   VARCHAR2(255 CHAR),
  TRANS_CODE        VARCHAR2(32 CHAR), 
  TARGET_MEMBER_ID  VARCHAR2(32 CHAR),
  SOURCE_MEMBER_ID  VARCHAR2(32 CHAR),
  SETTL_CURR        VARCHAR2(3 CHAR),
  FILE_ID           VARCHAR2(32 CHAR),
  TRANS_LEVEL       VARCHAR2(4 CHAR),
  TRANS_DETAILS     VARCHAR2(4000 CHAR),
  CARD_NUMBER       VARCHAR2(4000 CHAR),
  TRANS_DATE        DATE,
  RECONS_AMOUNT     NUMBER,
  RECONS_CURR       VARCHAR2(3 CHAR),
  SETTL_AMOUNT      NUMBER,
  FEE_AMNT          NUMBER,
  POSTING_STATUS    VARCHAR2(1 CHAR),
  REQUEST_CATEGORY  VARCHAR2(4000 CHAR),
  MAIN_CONTRACT     VARCHAR2(255 CHAR),
  ID                NUMBER(18)                  NOT NULL,
  RECONS_EXPONENT   VARCHAR2(1 CHAR),
  SETTL_EXPONENT    VARCHAR2(1 CHAR),
  ACQ_REF_NUMBER    VARCHAR2(32 CHAR),
  AUTH_CODE         VARCHAR2(32 CHAR),
  POSTING_DATE      DATE,
  REASON_CODE       VARCHAR2(32 CHAR),
  REASON_DETAILS    VARCHAR2(3900 CHAR),
  ISS_REF_NUMBER    VARCHAR2(32 CHAR),
  TRANS_GROUP       VARCHAR2(14 CHAR)
)
TABLESPACE OWLARGE_D]');
  
  <<SKIP>>
  /*NEVER DELETE THIS*/ opt_ctr_util.RELEASE_SUBPROCESS_END2(ToReject, AppErrorText, AppErrorNumber); --Closes the current process and session if needed, will reject if ToReject was set to stnd.Yes.
END;
/