-- create table used for recon reports creation during ENBD migration
declare
c dtype.Counter %type;
sqlStr dtype.LongStr %type;
rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE: create OPT_MIGR_LOOKUP_MAPPING table', null, stnd.No);
  select min(1) into c from user_tables where table_name = 'OPT_MIGR_LOOKUP_MAPPING';
  if c is null then
     sqlStr := 'CREATE TABLE OPT_MIGR_LOOKUP_MAPPING
( BANK_CODE             VARCHAR2(32 CHAR),
  WAY4_KEY              VARCHAR2(50 CHAR),
  WAY4_VALUE            VARCHAR2(100 CHAR),
  LEGACY_VALUE          VARCHAR2(100 CHAR),
  DESCRIPTION           VARCHAR2(100 CHAR),
  PLAN_TYPE             VARCHAR2(30 CHAR), 
  PLAN_TYPE2             VARCHAR2(30 CHAR) 
) nologging
';
     execute immediate sqlStr;          
     sqlStr := 'create unique index OPT_MIGR_LOOKUP_MAPPING_UK on OPT_MIGR_LOOKUP_MAPPING (BANK_CODE,WAY4_KEY,WAY4_VALUE)';
     execute immediate sqlStr;          
     stnd.process_message(stnd.Information, 'Table OPT_MIGR_LOOKUP_MAPPING is created.');
  end if;   
  stnd.process_end;
end;
/
