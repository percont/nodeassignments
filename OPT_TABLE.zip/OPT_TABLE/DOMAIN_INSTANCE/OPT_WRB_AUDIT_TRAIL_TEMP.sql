-- OPT_WRB_AUDIT_TRAIL_TEMP
-- Usage: WARBA_Is_Ou_Audit_TrailRprt report
-- 20190123.001 table created


DECLARE
  v_table_name user_tables.table_name%TYPE:= 'OPT_WRB_AUDIT_TRAIL_TEMP';
BEGIN
  begin
	execute immediate 'DROP TABLE '|| v_table_name;
	exception when others then null;
  end;
  for rec in (select 1 from user_tables where table_name = v_table_name having count(1) = 0)
  loop
      execute immediate '
            CREATE TABLE '||v_table_name||'
               (ACT_DATE	     DATE,
                TO_STR_STEP	     NUMBER,
                RESULT	         NUMBER,
                NAME	         VARCHAR2(4000),
                CHECKER_ID	     VARCHAR2(4000),
                CHECKER_NAME     VARCHAR2(4000),
                MAKER_ID	     VARCHAR2(4000),
                MAKER_NAME	     VARCHAR2(4000),
                C_NAME	         VARCHAR2(4000),
                M_NAME	         VARCHAR2(4000),
                CLIENT_ID	     NUMBER,
                F_I	             NUMBER,
                ID	             NUMBER,
				OBJECT_TYPE      VARCHAR2(4000),
				ACNT_CONTRACT_ID NUMBER,
				AMND_STATE       VARCHAR2(4000),
				ADV_APPL__OID    NUMBER
				)';
  end loop;
 END;
/	