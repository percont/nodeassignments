-- OPT_MAKER_CHECKER_REPORT_VA
-- Usage: BR_IS_Ou_Maker_Checker_Report, PETRA_CL_MnC_NonMonetary_Rep.rdf
-- 20210830.001 table created 


DECLARE
  v_table_name user_tables.table_name%TYPE:= 'OPT_MAKER_CHECKER_REPORT_VA';
BEGIN
  begin
	execute immediate 'DROP TABLE '|| v_table_name;
	exception when others then null;
  end;
  for rec in (select 1 from user_tables where table_name = v_table_name having count(1) = 0)
  loop
      execute immediate '
            CREATE TABLE '||v_table_name||'
               (ORG VARCHAR2(2000),
                ID NUMBER NOT NULL ENABLE, 
	            OBJECT_FOR_ID NUMBER, 
	            OUTWARD_STATUS VARCHAR2(2000), 
	            OBJECT_TYPE VARCHAR2(2000), 
	            ACTION_TYPE VARCHAR2(2000), 
	            ACNT_CONTRACT_ID NUMBER, 
	            CLIENT_ID NUMBER, 
	            APPL_REG_NUMBER VARCHAR2(2000),
	            WF_OBJECT_ID NUMBER,
                ADV_APPL__OID NUMBER,
	            OBJECT_FOR VARCHAR2(2000),
                AMND_OFFICER VARCHAR2(2000),
                AMND_DATE DATE)';
  end loop;
 END;
/	