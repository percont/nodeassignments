DECLARE
/*
 * Creates opt_tariff_migration table.
 */

  TabName         dtype.Name    %type := 'OPT_TD_AUTH_MIGR';
  TableCount      dtype.Counter%type;
  SqlStr          DTYPE.LONGSTR%type;
  sqlLongStr      dtype.XMLString%type;
  ProcRc          dtype.Counter%type;
  ToRecreate      CONSTANT dtype.Tag%type := 'Y'; -- TODO Need to change before go-live!
  IsTestEnv       dtype.Tag%type;

BEGIN
  ProcRc := stnd.process_start('OPT_TABLE: ' || TabName || ' - Create table', null, stnd.No);
  IsTestEnv := opt_pei_forms.IS_TEST_ENV;
  
  select count(*) into TableCount from user_tables where table_name = TabName;
  if TableCount > 0 and ToRecreate = stnd.Yes then
  
    BEGIN
      SqlStr := 'drop sequence '|| TabName || '_SEQ';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'alter table '|| TabName ||' drop primary key cascade';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'drop table '|| TabName || ' cascade constraints';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END; 

  elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table '|| TabName || ' does exist and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
    -- Table
    sqlLongStr := 
      '
create table '||TabName||' (   
   id                       number(18) not null constraint PK_'||TabName||' primary key,
   acnt_contract__id        number(18) not null,
   TD_AUTH_TYPE__ID         number(18) not null,
   TD_AUTH_TYPE             varchar2(64),
   AUTH_IDT                 varchar2(64),
   AUTH_IDT_EXTENSION       varchar2(64),
   outward_status           varchar2(1) default ''W''
) initrans 100
    ';
    execute immediate sqlLongStr;
    stnd.process_message(stnd.Information, 'Table created.');


sqlStr := 'comment on column '||TabName||'.outward_status is ''W - Waiting, S - Suspended, P - Posted, J - Rejected''';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'COMMENT created.');

sqlStr := 'create index '||TabName||'_outward on '||TabName||' (outward_status, acnt_contract__id, id)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created: ' || sqlStr);

sqlStr := 'grant select, update on '||TabName||' to owsrnets';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Granted');  
    
  <<SKIP>>
  stnd.PROCESS_END;
  END;
/