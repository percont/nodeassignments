-- OPT_BBY_AUDIT_TRAIL_VA_MC
-- Usage: BBY_IS_Ou_Audit_TrailRprt report
-- 20200703.001 table created


DECLARE
  v_table_name user_tables.table_name%TYPE:= 'OPT_BBY_AUDIT_TRAIL_VA_MC';
BEGIN
  begin
	execute immediate 'DROP TABLE '|| v_table_name;
	exception when others then null;
  end;
  for rec in (select 1 from user_tables where table_name = v_table_name having count(1) = 0)
  loop
      execute immediate '
            CREATE TABLE '||v_table_name||'
               (REPORT_TYPE NUMBER,
			    VA_ID       NUMBER,
                MAN         VARCHAR2(4000),
                MAG         VARCHAR2(4000),
                CHN         VARCHAR2(4000),
                CHG         VARCHAR2(4000)
                )';
  end loop;
 END;
/	