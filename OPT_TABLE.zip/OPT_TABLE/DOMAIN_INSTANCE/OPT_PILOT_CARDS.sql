-- create table used for recon reports creation during ENBD migration
declare
c dtype.Counter %type;
sqlStr dtype.LongStr %type;
rc dtype.Counter %type;
begin
  rc := stnd.process_start('OPT_TABLE: create OPT_PILOT_CARDS table', null, stnd.No);
  select min(1) into c from user_tables where table_name = 'OPT_PILOT_CARDS';
  if c is null then
     sqlStr := 'CREATE TABLE OPT_PILOT_CARDS
( BANK_CODE          VARCHAR2(32 CHAR),
  CARD_NBR           VARCHAR2(64 CHAR),
  ACCOUNT_NBR        VARCHAR2(64 CHAR),
  CUSTOMER_NBR       VARCHAR2(64 CHAR),  
  CUST_CIF           VARCHAR2(64 CHAR) ) ';
     execute immediate sqlStr;          
     sqlStr := 'create unique index OPT_PILOT_CARDS_UK on OPT_PILOT_CARDS (BANK_CODE,CARD_NBR,ACCOUNT_NBR,CUSTOMER_NBR)';
     execute immediate sqlStr;          
     stnd.process_message(stnd.Information, 'Table OPT_PILOT_CARDS is created.');
  end if;   
  stnd.process_end;
end;
/
