-- OPT_MAKER_CHECKER_REPORT_CA
-- Usage: BR_IS_Ou_Maker_Checker_Report report, PETRA_CL_MnC_NonMonetary_Rep.rdf
-- 20210830.001 table created 


DECLARE
  v_table_name user_tables.table_name%TYPE:= 'OPT_MAKER_CHECKER_REPORT_CA';
BEGIN
  begin
	execute immediate 'DROP TABLE '|| v_table_name;
	exception when others then null;
  end;
  for rec in (select 1 from user_tables where table_name = v_table_name having count(1) = 0)
  loop
      execute immediate '
            CREATE TABLE '||v_table_name||'
               (ORG VARCHAR2(2000),
                RNUM NUMBER, 
	            CM_CASE__OID NUMBER, 
	            TO_STR_STEP NUMBER, 
	            RESULT NUMBER, 
	            ACTIV_DATE DATE, 
	            NAME VARCHAR2(2000), 
	            PERFORMED_BY NUMBER)';
  end loop;
 END;
/