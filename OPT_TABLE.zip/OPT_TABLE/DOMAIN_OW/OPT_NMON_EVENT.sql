DECLARE
/*
 * Creates opt_nmon_event table. This script should be executed
 * BEFORE compilation of opt_ow_nmon/opt_ni_nmon packages
 */

  TabName       dtype.Name    %type := 'OPT_NMON_EVENT';
  TableCount 	dtype.Counter%type;
  SqlStr      DTYPE.LONGSTR%type;
  sqlLongStr 		dtype.XMLString%type;
  ProcRc 		dtype.Counter%type;
  ToRecreate 	CONSTANT dtype.Tag%type := 'N'; -- TODO Need to change before go-live!
  IsTestEnv 	dtype.Tag%type;

BEGIN
	ProcRc := stnd.process_start('OPT_TABLE: ' || TabName || ' - Create table', null, stnd.No);
	IsTestEnv := opt_flex_tools.IS_TEST_ENV;
	
	select count(*) into TableCount from user_tables where table_name = TabName;
	if TableCount > 0 and ToRecreate = stnd.Yes then
	
    BEGIN
      SqlStr := 'alter table '|| TabName ||' drop primary key cascade';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END;

    BEGIN
      SqlStr := 'drop table '|| TabName || ' cascade constraints';
      EXECUTE IMMEDIATE SqlStr;
    EXCEPTION WHEN OTHERS THEN
      stnd.PROCESS_MESSAGE(stnd.Trace, 'Object does not exist at SQL:"' || SqlStr || '"');
    END; 

	elsif TableCount > 0 then
    stnd.PROCESS_MESSAGE(stnd.Information, 'Table '|| TabName || ' does exist and recreation is not enabled or possible'
      || '; IsTestEnv=' || IsTestEnv 
      || '; ToRecreate=' || ToRecreate 
    );
    GOTO SKIP;
  end if;
    -- Table
    sqlLongStr := 
      '
create table opt_nmon_event (
   /* Event ID */
   id                       number(18)  not null constraint pk_opt_nmon_event primary key,
   /* Event Context */
   connection_id            number(18),
   officer_id               number(18),
   process_log_id           number(18),
   /* Message Status */
   outward_status           varchar2(1) not null,
   capture_time             timestamp   not null,
   delivery_time            timestamp,
   delivery_count           number(2)   not null,
   /* WAY4 Objects */
   f_i                      number(18)  not null,
   client_id                number(18)  not null,
   client_address_id        number(18),
   acnt_contract_id         number(18),
   new_acnt_contract_id     number(18),
   card_contract_id         number(18),
   new_card_contract_id     number(18),
   card_info_id             number(18),
   new_card_info_id         number(18),
   /* Event Code */
   nmon_code                varchar(5)  not null,
   action_code              varchar(2),
   /* Message Content */
   new_given_name           varchar2(30),
   old_given_name           varchar2(30),
   new_middle_name          varchar2(30),
   old_middle_name          varchar2(30),
   new_surname              varchar2(60),
   old_surname              varchar2(60),
   new_suffix               varchar2(10),
   old_suffix               varchar2(10),
   new_entity_name          varchar2(60),
   old_entity_name          varchar2(60),
   new_street_line_1        varchar2(40),
   old_street_line_1        varchar2(40),
   new_street_line_2        varchar2(40),
   old_street_line_2        varchar2(40),
   new_street_line_3        varchar2(40),
   old_street_line_3        varchar2(40),
   new_street_line_4        varchar2(40),
   old_street_line_4        varchar2(40),
   new_city                 varchar2(40),
   old_city                 varchar2(40),
   new_state_province       varchar2(3),
   old_state_province       varchar2(3),
   new_postal_code          varchar2(10),
   old_postal_code          varchar2(10),
   new_country_code         varchar2(3),
   old_country_code         varchar2(3),
   new_phone_1              varchar2(24),
   old_phone_1              varchar2(24),
   new_phone_2              varchar2(24),
   old_phone_2              varchar2(24),
   new_email_address        varchar2(40),
   old_email_address        varchar2(40),
   new_date_1               date,
   old_date_1               date,
   new_date_2               date,
   old_date_2               date,
   new_id_1                 varchar2(20),
   old_id_1                 varchar2(20),
   new_id_2                 varchar2(20),
   old_id_2                 varchar2(20),
   new_code_1               varchar2(3),
   old_code_1               varchar2(3),
   new_code_2               varchar2(3),
   old_code_2               varchar2(3),
   new_code_3               varchar2(3),
   old_code_3               varchar2(3),
   new_indicator_1          varchar2(1),
   old_indicator_1          varchar2(1),
   new_indicator_2          varchar2(1),
   old_indicator_2          varchar2(1),
   new_indicator_3          varchar2(1),
   old_indicator_3          varchar2(1),
   new_indicator_4          varchar2(1),
   old_indicator_4          varchar2(1),
   new_monetary_value       number(28, 10),
   old_monetary_value       number(28, 10),
   currency_code            varchar2(3),
   currency_conversion_rate number(28, 10),
   new_numeric_value_1      number(10),
   old_numeric_value_1      number(10),
   new_numeric_value_2      number(10),
   old_numeric_value_2      number(10),
   new_character_value      varchar2(10),
   old_character_value      varchar2(10),
   new_text                 varchar2(60),
   old_text                 varchar2(60),
   comment_text             varchar2(50),
   user_indicator_1         varchar2(1),
   user_indicator_2         varchar2(1),
   user_indicator_3         varchar2(1),
   user_indicator_4         varchar2(1),
   user_indicator_5         varchar2(1),
   user_code_1              varchar2(3),
   user_code_2              varchar2(3),
   user_code_3              varchar2(3),
   user_code_4              varchar2(3),
   user_code_5              varchar2(3),
   user_data_1              varchar2(6),
   user_data_2              varchar2(6),
   user_data_3              varchar2(6),
   user_data_4              varchar2(8),
   user_data_5              varchar2(8),
   user_data_6              varchar2(8),
   user_data_7              varchar2(10),
   user_data_8              varchar2(10),
   user_data_9              varchar2(15),
   user_data_10             varchar2(15),
   user_data_11             varchar2(20),
   user_data_12             varchar2(20),
   user_data_13             varchar2(40),
   user_data_14             varchar2(40),
   user_data_15             varchar2(60)
) initrans 100
    ';
    execute immediate sqlLongStr;
    stnd.process_message(stnd.Information, 'Table created.');


sqlStr := 'comment on column opt_nmon_event.outward_status is ''W - Waiting, S - Suspended, P - Posted, J - Rejected, F - Failed''';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'COMMENT created.');

sqlStr := 'create index opt_nmon_event_outward on opt_nmon_event (outward_status, delivery_count, id)';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Index created: ' || sqlStr);

sqlStr := 'declare
		   SequenceAlreadyExists boolean;
		begin
		   -- Check if sequence already exists
		   SequenceAlreadyExists := false;
		   for SequenceRec in (select *
							   from all_sequences
							   where sequence_name = '''||TabName||'_SEQ'')
		   loop
			  SequenceAlreadyExists := true;
		   end loop;
		   -- Create sequence if necessary
		   if SequenceAlreadyExists then
			  null; -- We never drop the sequence, as Falcon requires counter to be always unique
		   else
			  execute immediate ''create sequence '||TabName||'_seq increment by 1 start with 1'';
		   end if;
		end;';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Sequence created.');

sqlStr := 'grant select, update on opt_nmon_event to owsrnets';
    execute immediate sqlStr;
    stnd.process_message(stnd.Information, 'Granted');  
    
  <<SKIP>>
  stnd.PROCESS_END;
  END;
/
